<?php
/*
1.0.0 26 April 2008 
- QContacts released!

1.0.1 1 May 2008
- Added file install.nonutf8.sql for installation on non utf8 databases

1.0.2 30 May 2008
- fix: address icon sometimes shown on contact page when no address fields 
were set to visible.
- fix: Use Global setting not working on some configuration parameters for 
contacts imported from com_contact.
- fix: page title not shown on contact page even when Show Page Title was 
set to Yes in Category Layout menu.
- fix: drop down list not shown on contact page even when Drop Down was
set to Show on Standard Contact Layout menu.

1.0.3 28 July 2008
- new: added many new configuration parameters to control captcha 
appearance: code lenght, image width and height, foreground and background 
color, font, vertical and arc lines on/off.
- new: more field types allowed for custom fields: checkbox, radio buttons,
 drop down list.
- new: added a Field Order parameter to control the position of custom and 
standard fields on the form.
- new: an asterisk (or another symbol) can optionally be displayed near 
required fields. In addition required fields style can be controlled with 
css (label.required selector).
- new: all contact fields (name, position, e-mail, phone, mobile, fax, 
street, city, state, postcode, country) can be displayed in Category Layout 
lists. Each column width and order can be set via configuration parameters.
- new: Contacts per Page parameter add to Contact Category Layout menu to 
control the maximum number of records per page on the list.
* */
?>