-- phpMyAdmin SQL Dump
-- version 2.11.7
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 04, 2008 at 11:22 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `joomla`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_redirection`
--

DROP TABLE IF EXISTS `jos_redirection`;
CREATE TABLE IF NOT EXISTS `jos_redirection` (
  `id` int(11) NOT NULL auto_increment,
  `cpt` int(11) NOT NULL default '0',
  `rank` int(11) NOT NULL default '0',
  `oldurl` varchar(255) NOT NULL default '',
  `newurl` varchar(255) NOT NULL default '',
  `dateadd` date NOT NULL default '0000-00-00',
  PRIMARY KEY  (`id`),
  KEY `newurl` (`newurl`),
  KEY `rank` (`rank`),
  KEY `oldurl` (`oldurl`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=251 ;

--
-- Dumping data for table `jos_redirection`
--

INSERT INTO `jos_redirection` (`id`, `cpt`, `rank`, `oldurl`, `newurl`, `dateadd`) VALUES
(202, 0, 0, 'Unions/K-N-Varghese', 'index.php?option=com_contact&Itemid=59&id=111&lang=en&view=contact', '0000-00-00'),
(201, 0, 0, 'Unions/K-J-Varghese', 'index.php?option=com_contact&Itemid=59&id=108&lang=en&view=contact', '0000-00-00'),
(200, 0, 0, 'Unions/Mary-Thomas', 'index.php?option=com_contact&Itemid=59&id=109&lang=en&view=contact', '0000-00-00'),
(199, 0, 0, 'Unions/S-Stanley', 'index.php?option=com_contact&Itemid=59&id=104&lang=en&view=contact', '0000-00-00'),
(198, 0, 0, 'Unions/P-H-Paulson', 'index.php?option=com_contact&Itemid=59&id=105&lang=en&view=contact', '0000-00-00'),
(197, 1, 0, 'Unions/P-T-Johnkutty', 'index.php?option=com_contact&Itemid=59&id=106&lang=en&view=contact', '0000-00-00'),
(196, 0, 0, 'Unions/Philip-S-Jacob', 'index.php?option=com_contact&Itemid=59&id=112&lang=en&view=contact', '0000-00-00'),
(195, 0, 0, 'Unions/V-K-Baby', 'index.php?option=com_contact&Itemid=59&id=110&lang=en&view=contact', '0000-00-00'),
(194, 0, 0, 'Unions/Raju-Abraham', 'index.php?option=com_contact&Itemid=59&id=113&lang=en&view=contact', '0000-00-00'),
(193, 0, 0, 'Table/Unions/feed/atom', 'index.php?option=com_content&Itemid=59&catid=47&format=feed&lang=en&type=atom&view=category', '0000-00-00'),
(192, 0, 0, 'Table/Unions/feed/rss', 'index.php?option=com_content&Itemid=59&catid=47&format=feed&lang=en&type=rss&view=category', '0000-00-00'),
(191, 0, 0, 'Departments/Edison-Samraj', 'index.php?option=com_contact&Itemid=19&id=46&lang=en&view=contact', '0000-00-00'),
(190, 0, 0, 'Table/Departments/feed/atom', 'index.php?option=com_content&Itemid=19&catid=41&format=feed&lang=en&type=atom&view=category', '0000-00-00'),
(189, 0, 0, 'Table/Departments/feed/rss', 'index.php?option=com_content&Itemid=19&catid=41&format=feed&lang=en&type=rss&view=category', '0000-00-00'),
(188, 0, 0, 'Departments/Youth/', 'index.php?option=com_contact&Itemid=19&catid=17&lang=en&view=category', '0000-00-00'),
(187, 0, 0, 'Departments/Women-s-Ministries/', 'index.php?option=com_contact&Itemid=19&catid=30&lang=en&view=category', '0000-00-00'),
(186, 0, 0, 'Departments/TRUST-Services/', 'index.php?option=com_contact&Itemid=19&catid=29&lang=en&view=category', '0000-00-00'),
(185, 0, 0, 'Departments/Treasury/', 'index.php?option=com_contact&Itemid=19&catid=9&lang=en&view=category', '0000-00-00'),
(184, 0, 0, 'Departments/Stewardship/', 'index.php?option=com_contact&Itemid=19&catid=20&lang=en&view=category', '0000-00-00'),
(183, 0, 0, 'Departments/Spirit-of-Prophecy/', 'index.php?option=com_contact&Itemid=19&catid=34&lang=en&view=category', '0000-00-00'),
(182, 0, 0, 'Departments/Special-Ministries/', 'index.php?option=com_contact&Itemid=19&catid=28&lang=en&view=category', '0000-00-00'),
(181, 0, 0, 'Departments/Southern-Asia-Tidings/', 'index.php?option=com_contact&Itemid=19&catid=32&lang=en&view=category', '0000-00-00'),
(180, 0, 0, 'Departments/Secretariat/', 'index.php?option=com_contact&Itemid=19&catid=8&lang=en&view=category', '0000-00-00'),
(179, 0, 0, 'Departments/Satellite-Evangelism/', 'index.php?option=com_contact&Itemid=19&catid=35&lang=en&view=category', '0000-00-00'),
(178, 0, 0, 'Departments/Sabbath-School/', 'index.php?option=com_contact&Itemid=19&catid=25&lang=en&view=category', '0000-00-00'),
(177, 0, 0, 'Departments/Retirement-Plan/', 'index.php?option=com_contact&Itemid=19&catid=24&lang=en&view=category', '0000-00-00'),
(176, 0, 0, 'Departments/Publishing/', 'index.php?option=com_contact&Itemid=19&catid=23&lang=en&view=category', '0000-00-00'),
(175, 0, 0, 'Departments/Personal-Ministries/', 'index.php?option=com_contact&Itemid=19&catid=26&lang=en&view=category', '0000-00-00'),
(174, 0, 0, 'Departments/PARL/', 'index.php?option=com_contact&Itemid=19&catid=13&lang=en&view=category', '0000-00-00'),
(173, 0, 0, 'Departments/Oriental-Watchman-Publishing-House/', 'index.php?option=com_contact&Itemid=19&catid=40&lang=en&view=category', '0000-00-00'),
(172, 0, 0, 'Departments/Ministry-to-the-Blind/', 'index.php?option=com_contact&Itemid=19&catid=27&lang=en&view=category', '0000-00-00'),
(171, 0, 0, 'Departments/Ministerial/', 'index.php?option=com_contact&Itemid=19&catid=22&lang=en&view=category', '0000-00-00'),
(170, 0, 0, 'Departments/Legal-Affairs/', 'index.php?option=com_contact&Itemid=19&catid=42&lang=en&view=category', '0000-00-00'),
(169, 1, 0, 'Departments/Intra-Church-Publications/', 'index.php?option=com_contact&Itemid=19&catid=41&lang=en&view=category', '0000-00-00'),
(168, 0, 0, 'Departments/Hinduism-Study-Center/', 'index.php?option=com_contact&Itemid=19&catid=33&lang=en&view=category', '0000-00-00'),
(167, 0, 0, 'Departments/Health-and-Temperance/', 'index.php?option=com_contact&Itemid=19&catid=19&lang=en&view=category', '0000-00-00'),
(166, 0, 0, 'Departments/Global-Mission/', 'index.php?option=com_contact&Itemid=19&catid=18&lang=en&view=category', '0000-00-00'),
(165, 0, 0, 'Departments/Family/', 'index.php?option=com_contact&Itemid=19&catid=16&lang=en&view=category', '0000-00-00'),
(164, 0, 0, 'Departments/Faith-Development-In-Context/', 'index.php?option=com_contact&Itemid=19&catid=14&lang=en&view=category', '0000-00-00'),
(163, 0, 0, 'Departments/Education/', 'index.php?option=com_contact&Itemid=19&catid=5&lang=en&view=category', '0000-00-00'),
(162, 0, 0, 'Departments/Department-of-Legal-Affairs/', 'index.php?option=com_contact&Itemid=19&catid=21&lang=en&view=category', '0000-00-00'),
(161, 0, 0, 'Departments/Communication/', 'index.php?option=com_contact&Itemid=19&catid=4&lang=en&view=category', '0000-00-00'),
(160, 0, 0, 'Departments/Church-Nurturing-Ministries/', 'index.php?option=com_contact&Itemid=19&catid=11&lang=en&view=category', '0000-00-00'),
(159, 0, 0, 'Departments/Children-s-Ministries/', 'index.php?option=com_contact&Itemid=19&catid=10&lang=en&view=category', '0000-00-00'),
(158, 1, 0, 'Departments/Chaplaincy/', 'index.php?option=com_contact&Itemid=19&catid=12&lang=en&view=category', '0000-00-00'),
(157, 0, 0, 'Departments/Building/', 'index.php?option=com_contact&Itemid=19&catid=36&lang=en&view=category', '0000-00-00'),
(156, 0, 0, 'Departments/Auditing-Service/', 'index.php?option=com_contact&Itemid=19&catid=31&lang=en&view=category', '0000-00-00'),
(155, 0, 0, 'Departments/Adventist-Volunteer-Service/', 'index.php?option=com_contact&Itemid=19&catid=38&lang=en&view=category', '0000-00-00'),
(154, 0, 0, 'Departments/Adventist-Risk-Management/', 'index.php?option=com_contact&Itemid=19&catid=37&lang=en&view=category', '0000-00-00'),
(153, 1, 0, 'Departments/Adventist-Media-Centre/', 'index.php?option=com_contact&Itemid=19&catid=39&lang=en&view=category', '0000-00-00'),
(152, 0, 0, 'Departments/Adventist-Child-India/', 'index.php?option=com_contact&Itemid=19&catid=15&lang=en&view=category', '0000-00-00'),
(151, 0, 0, 'Departments/Administrators/', 'index.php?option=com_contact&Itemid=19&catid=7&lang=en&view=category', '0000-00-00'),
(150, 0, 0, 'Unions/Western-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=46&lang=en&view=category', '0000-00-00'),
(149, 1, 0, 'Unions/Southwest-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=47&lang=en&view=category', '0000-00-00'),
(148, 0, 0, 'Unions/Southeast-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=48&lang=en&view=category', '0000-00-00'),
(147, 0, 0, 'Unions/South-Central-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=49&lang=en&view=category', '0000-00-00'),
(146, 0, 0, 'Unions/Northern-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=50&lang=en&view=category', '0000-00-00'),
(145, 0, 0, 'Unions/Northeast-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=51&lang=en&view=category', '0000-00-00'),
(144, 0, 0, 'Unions/East-Central-India-Union/', 'index.php?option=com_contact&Itemid=59&catid=45&lang=en&view=category', '0000-00-00'),
(143, 0, 0, 'Directory/Lionel-F-Lyngdoh', 'index.php?option=com_contact&Itemid=20&id=22&lang=en&view=contact', '0000-00-00'),
(142, 0, 0, 'Directory/Anita-Livingston', 'index.php?option=com_contact&Itemid=20&id=26&lang=en&view=contact', '0000-00-00'),
(141, 0, 0, 'Directory/T-P-Kurian', 'index.php?option=com_contact&Itemid=20&id=21&lang=en&view=contact', '0000-00-00'),
(140, 0, 0, 'Directory/Ramani-Kurian', 'index.php?option=com_contact&Itemid=20&id=20&lang=en&view=contact', '0000-00-00'),
(139, 0, 0, 'Directory/Hepzibah-Kore', 'index.php?option=com_contact&Itemid=20&id=34&lang=en&view=contact', '0000-00-00'),
(138, 0, 0, 'Directory/Ganaraj-W-Kore', 'index.php?option=com_contact&Itemid=20&id=30&lang=en&view=contact', '0000-00-00'),
(137, 0, 0, 'Directory/M-D-Joseph', 'index.php?option=com_contact&Itemid=20&id=24&lang=en&view=contact', '0000-00-00'),
(135, 0, 0, 'Directory/R-John', 'index.php?option=com_contact&Itemid=20&id=6&lang=en&view=contact', '0000-00-00'),
(136, 0, 0, 'Directory/Rachel-John', 'index.php?option=com_contact&Itemid=20&id=43&lang=en&view=contact', '0000-00-00'),
(134, 0, 0, 'Directory/M-C-John', 'index.php?option=com_contact&Itemid=20&id=8&lang=en&view=contact', '0000-00-00'),
(133, 0, 0, 'Directory/Flora-John', 'index.php?option=com_contact&Itemid=20&id=42&lang=en&view=contact', '0000-00-00'),
(132, 0, 0, 'Directory/Ramesh-Y-Jadhav', 'index.php?option=com_contact&Itemid=20&id=23&lang=en&view=contact', '0000-00-00'),
(131, 0, 0, 'Directory/Paulraj-Isaiah', 'index.php?option=com_contact&Itemid=20&id=19&lang=en&view=contact', '0000-00-00'),
(130, 1, 0, 'Directory/William-George', 'index.php?option=com_contact&Itemid=20&id=31&lang=en&view=contact', '0000-00-00'),
(129, 1, 0, 'Directory/Mathew-Devasahayam', 'index.php?option=com_contact&Itemid=20&id=37&lang=en&view=contact', '0000-00-00'),
(128, 0, 0, 'Directory/G-S-Robert-Clive', 'index.php?option=com_contact&Itemid=20&id=7&lang=en&view=contact', '0000-00-00'),
(127, 0, 0, 'Directory/Rosenita-Christo', 'index.php?option=com_contact&Itemid=20&id=38&lang=en&view=contact', '0000-00-00'),
(126, 0, 0, 'Directory/Gordon-Christo', 'index.php?option=com_contact&Itemid=20&id=2&lang=en&view=contact', '0000-00-00'),
(125, 0, 0, 'Directory/Edwin-Charles', 'index.php?option=com_contact&Itemid=20&id=44&lang=en&view=contact', '0000-00-00'),
(124, 0, 0, 'Directory/Jothi-J-Anbiah', 'index.php?option=com_contact&Itemid=20&id=16&lang=en&view=contact', '0000-00-00'),
(123, 0, 0, 'Table/Directory/feed/atom', 'index.php?option=com_content&Itemid=20&format=feed&lang=en&type=atom&view=category', '0000-00-00'),
(122, 0, 0, 'Table/Directory/feed/rss', 'index.php?option=com_content&Itemid=20&format=feed&lang=en&type=rss&view=category', '0000-00-00'),
(121, 0, 0, 'SDA-Information/history-sda-india', 'index.php?option=com_content&Itemid=7&id=6&lang=en&view=article', '0000-00-00'),
(120, 0, 0, 'SDA-Information/adventist-neighbour', 'index.php?option=com_content&Itemid=10&id=10&lang=en&view=article', '0000-00-00'),
(119, 0, 0, 'SDA-Information/history-sda', 'index.php?option=com_content&Itemid=9&id=9&lang=en&view=article', '0000-00-00'),
(118, 1, 0, 'SDA-Information/sda-logo', 'index.php?option=com_content&Itemid=8&id=5&lang=en&view=article', '0000-00-00'),
(117, 1, 0, 'SDA-Information/mission', 'index.php?option=com_content&Itemid=6&id=4&lang=en&view=article', '0000-00-00'),
(116, 1, 0, 'SDA-Information/what-sda-believe', 'index.php?option=com_content&Itemid=5&id=7&lang=en&view=article', '0000-00-00'),
(115, 1, 0, 'SDA-Information/sda-info-brief', 'index.php?option=com_content&Itemid=4&id=8&lang=en&view=article', '0000-00-00'),
(113, 2, 0, 'Unions', 'index.php?option=com_contact&Itemid=59&lang=en&view=categories', '0000-00-00'),
(114, 2, 0, 'Division-Information/contact-us', 'index.php?option=com_content&Itemid=2&id=2&lang=en&view=article', '0000-00-00'),
(112, 7, 0, 'Departments', 'index.php?option=com_contact&Itemid=19&lang=en&view=categories', '0000-00-00'),
(111, 10, 0, 'Directory/category/', 'index.php?option=com_contact&Itemid=20&lang=en&view=category', '0000-00-00'),
(110, 0, 0, 'feed/atom', 'index.php?option=com_content&Itemid=1&format=feed&lang=en&type=atom&view=frontpage', '0000-00-00'),
(109, 0, 0, 'feed/rss', 'index.php?option=com_content&Itemid=1&format=feed&lang=en&type=rss&view=frontpage', '0000-00-00'),
(203, 0, 0, 'Unions/Sosamma-Varghese', 'index.php?option=com_contact&Itemid=59&id=107&lang=en&view=contact', '0000-00-00'),
(204, 0, 1, 'Division-Information/contact-us', 'index.php?option=com_content&Itemid=2&catid=1&id=2&lang=en&view=article', '0000-00-00'),
(205, 0, 0, 'Division-Information/contact-us/Print', 'index.php?option=com_content&Itemid=2&catid=1&id=2&lang=en&page=0&print=1&tmpl=component&view=article', '0000-00-00'),
(206, 0, 0, 'pdf/Division-Information/contact-us.pdf', 'index.php?option=com_content&Itemid=2&catid=1&format=pdf&id=2&lang=en&view=article', '0000-00-00'),
(207, 0, 1, 'SDA-Information/sda-info-brief', 'index.php?option=com_content&Itemid=4&catid=2&id=8&lang=en&view=article', '0000-00-00'),
(208, 0, 0, 'SDA-Information/sda-info-brief/Print', 'index.php?option=com_content&Itemid=4&catid=2&id=8&lang=en&page=0&print=1&tmpl=component&view=article', '0000-00-00'),
(209, 0, 0, 'pdf/SDA-Information/sda-info-brief.pdf', 'index.php?option=com_content&Itemid=4&catid=2&format=pdf&id=8&lang=en&view=article', '0000-00-00'),
(210, 0, 1, 'SDA-Information/what-sda-believe', 'index.php?option=com_content&Itemid=5&catid=2&id=7&lang=en&view=article', '0000-00-00'),
(211, 0, 0, 'SDA-Information/what-sda-believe/Print', 'index.php?option=com_content&Itemid=5&catid=2&id=7&lang=en&page=0&print=1&tmpl=component&view=article', '0000-00-00'),
(212, 0, 0, 'pdf/SDA-Information/what-sda-believe.pdf', 'index.php?option=com_content&Itemid=5&catid=2&format=pdf&id=7&lang=en&view=article', '0000-00-00'),
(213, 0, 1, 'SDA-Information/mission', 'index.php?option=com_content&Itemid=6&catid=2&id=4&lang=en&view=article', '0000-00-00'),
(214, 0, 0, 'SDA-Information/mission/Print', 'index.php?option=com_content&Itemid=6&catid=2&id=4&lang=en&page=0&print=1&tmpl=component&view=article', '0000-00-00'),
(215, 0, 0, 'pdf/SDA-Information/mission.pdf', 'index.php?option=com_content&Itemid=6&catid=2&format=pdf&id=4&lang=en&view=article', '0000-00-00'),
(216, 0, 1, 'SDA-Information/sda-logo', 'index.php?option=com_content&Itemid=8&catid=2&id=5&lang=en&view=article', '0000-00-00'),
(217, 0, 0, 'SDA-Information/sda-logo/Print', 'index.php?option=com_content&Itemid=8&catid=2&id=5&lang=en&page=0&print=1&tmpl=component&view=article', '0000-00-00'),
(218, 0, 0, 'pdf/SDA-Information/sda-logo.pdf', 'index.php?option=com_content&Itemid=8&catid=2&format=pdf&id=5&lang=en&view=article', '0000-00-00'),
(219, 0, 1, 'Directory/category/', 'index.php?option=com_contact&Itemid=20&contact_section=1&lang=en&view=category', '0000-00-00'),
(220, 0, 1, 'Departments', 'index.php?option=com_contact&Itemid=19&contact_section=1&lang=en&view=categories', '0000-00-00'),
(221, 0, 1, 'Unions', 'index.php?option=com_contact&Itemid=59&contact_section=2&lang=en&view=categories', '0000-00-00'),
(222, 0, 0, 'Directory/Johnson-Abraham', 'index.php?option=com_contact&Itemid=20&id=81&lang=en&view=contact', '0000-00-00'),
(223, 0, 0, 'Directory/Raju-Abraham', 'index.php?option=com_contact&Itemid=20&id=113&lang=en&view=contact', '0000-00-00'),
(224, 0, 0, 'Directory/M-Anbalagan', 'index.php?option=com_contact&Itemid=20&id=102&lang=en&view=contact', '0000-00-00'),
(225, 0, 0, 'Directory/Anothindhas', 'index.php?option=com_contact&Itemid=20&id=98&lang=en&view=contact', '0000-00-00'),
(226, 0, 0, 'Directory/S-K-Archete', 'index.php?option=com_contact&Itemid=20&id=62&lang=en&view=contact', '0000-00-00'),
(227, 0, 0, 'Directory/V-M-Arokiasamy', 'index.php?option=com_contact&Itemid=20&id=99&lang=en&view=contact', '0000-00-00'),
(228, 0, 0, 'Directory/V-K-Baby', 'index.php?option=com_contact&Itemid=20&id=110&lang=en&view=contact', '0000-00-00'),
(229, 0, 0, 'Directory/S-B-Bairagi', 'index.php?option=com_contact&Itemid=20&id=73&lang=en&view=contact', '0000-00-00'),
(230, 0, 0, 'Directory/S-R-Bhatti', 'index.php?option=com_contact&Itemid=20&id=77&lang=en&view=contact', '0000-00-00'),
(231, 0, 0, 'Directory/Benedict-Biswas', 'index.php?option=com_contact&Itemid=20&id=74&lang=en&view=contact', '0000-00-00'),
(232, 0, 0, 'Directory/T-Robinson-Bob', 'index.php?option=com_contact&Itemid=20&id=55&lang=en&view=contact', '0000-00-00'),
(233, 0, 0, 'Directory/Rakesh-Chavan', 'index.php?option=com_contact&Itemid=20&id=117&lang=en&view=contact', '0000-00-00'),
(234, 0, 0, 'Directory/L-C-Colney', 'index.php?option=com_contact&Itemid=20&id=60&lang=en&view=contact', '0000-00-00'),
(235, 0, 0, 'Directory/Ramsangpuii-Colney', 'index.php?option=com_contact&Itemid=20&id=66&lang=en&view=contact', '0000-00-00'),
(236, 0, 0, 'Directory/Ranjan-D', 'index.php?option=com_contact&Itemid=20&id=82&lang=en&view=contact', '0000-00-00'),
(237, 0, 0, 'Departments/East-Central-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=45&lang=en&view=category', '0000-00-00'),
(238, 0, 0, 'Departments/Northeast-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=51&lang=en&view=category', '0000-00-00'),
(239, 0, 0, 'Departments/Northern-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=50&lang=en&view=category', '0000-00-00'),
(240, 0, 0, 'Departments/South-Central-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=49&lang=en&view=category', '0000-00-00'),
(241, 0, 0, 'Departments/Southeast-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=48&lang=en&view=category', '0000-00-00'),
(242, 0, 0, 'Departments/Southwest-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=47&lang=en&view=category', '0000-00-00'),
(243, 0, 0, 'Departments/The-Developers/', 'index.php?option=com_contact&Itemid=19&catid=52&lang=en&view=category', '0000-00-00'),
(244, 0, 0, 'Departments/Western-India-Union/', 'index.php?option=com_contact&Itemid=19&catid=46&lang=en&view=category', '0000-00-00'),
(245, 0, 1, 'Table/Departments/feed/rss', 'index.php?option=com_content&Itemid=19&catid=39&format=feed&lang=en&type=rss&view=category', '0000-00-00'),
(246, 0, 1, 'Table/Departments/feed/atom', 'index.php?option=com_content&Itemid=19&catid=39&format=feed&lang=en&type=atom&view=category', '0000-00-00'),
(247, 0, 0, 'Departments/Edwin-Charles', 'index.php?option=com_contact&Itemid=19&id=44&lang=en&view=contact', '0000-00-00'),
(248, 0, 2, 'Table/Departments/feed/rss', 'index.php?option=com_content&Itemid=19&catid=12&format=feed&lang=en&type=rss&view=category', '0000-00-00'),
(249, 0, 2, 'Table/Departments/feed/atom', 'index.php?option=com_content&Itemid=19&catid=12&format=feed&lang=en&type=atom&view=category', '0000-00-00'),
(250, 0, 0, 'Departments/Paulraj-Isaiah', 'index.php?option=com_contact&Itemid=19&id=19&lang=en&view=contact', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `jos_sh404sef_aliases`
--

DROP TABLE IF EXISTS `jos_sh404sef_aliases`;
CREATE TABLE IF NOT EXISTS `jos_sh404sef_aliases` (
  `id` int(11) NOT NULL auto_increment,
  `newurl` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `newurl` (`newurl`),
  KEY `alias` (`alias`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_sh404sef_aliases`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_sh404sef_meta`
--

DROP TABLE IF EXISTS `jos_sh404sef_meta`;
CREATE TABLE IF NOT EXISTS `jos_sh404sef_meta` (
  `id` int(11) NOT NULL auto_increment,
  `newurl` varchar(255) NOT NULL default '',
  `metadesc` varchar(255) default '',
  `metakey` varchar(255) default '',
  `metatitle` varchar(255) default '',
  `metalang` varchar(30) default '',
  `metarobots` varchar(30) default '',
  PRIMARY KEY  (`id`),
  KEY `newurl` (`newurl`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_sh404sef_meta`
--

