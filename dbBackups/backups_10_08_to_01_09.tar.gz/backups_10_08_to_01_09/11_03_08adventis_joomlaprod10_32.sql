-- phpMyAdmin SQL Dump
-- version 2.11.9.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 03, 2008 at 10:32 AM
-- Server version: 4.1.22
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `adventis_joomlaprod`
--

-- --------------------------------------------------------

--
-- Table structure for table `jos_banner`
--

DROP TABLE IF EXISTS `jos_banner`;
CREATE TABLE IF NOT EXISTS `jos_banner` (
  `bid` int(11) NOT NULL auto_increment,
  `cid` int(11) NOT NULL default '0',
  `type` varchar(30) NOT NULL default 'banner',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `imptotal` int(11) NOT NULL default '0',
  `impmade` int(11) NOT NULL default '0',
  `clicks` int(11) NOT NULL default '0',
  `imageurl` varchar(100) NOT NULL default '',
  `clickurl` varchar(200) NOT NULL default '',
  `date` datetime default NULL,
  `showBanner` tinyint(1) NOT NULL default '0',
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(50) default NULL,
  `custombannercode` text,
  `catid` int(10) unsigned NOT NULL default '0',
  `description` text NOT NULL,
  `sticky` tinyint(1) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `tags` text NOT NULL,
  `params` text NOT NULL,
  PRIMARY KEY  (`bid`),
  KEY `viewbanner` (`showBanner`),
  KEY `idx_banner_catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_banner`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_bannerclient`
--

DROP TABLE IF EXISTS `jos_bannerclient`;
CREATE TABLE IF NOT EXISTS `jos_bannerclient` (
  `cid` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `contact` varchar(255) NOT NULL default '',
  `email` varchar(255) NOT NULL default '',
  `extrainfo` text NOT NULL,
  `checked_out` tinyint(1) NOT NULL default '0',
  `checked_out_time` time default NULL,
  `editor` varchar(50) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_bannerclient`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_bannertrack`
--

DROP TABLE IF EXISTS `jos_bannertrack`;
CREATE TABLE IF NOT EXISTS `jos_bannertrack` (
  `track_date` date NOT NULL default '0000-00-00',
  `track_type` int(10) unsigned NOT NULL default '0',
  `banner_id` int(10) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_bannertrack`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_categories`
--

DROP TABLE IF EXISTS `jos_categories`;
CREATE TABLE IF NOT EXISTS `jos_categories` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` varchar(255) NOT NULL default '',
  `section` varchar(50) NOT NULL default '',
  `image_position` varchar(30) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `editor` varchar(50) default NULL,
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `contact_section` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `cat_idx` (`section`,`published`,`access`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=53 ;

--
-- Dumping data for table `jos_categories`
--

INSERT INTO `jos_categories` (`id`, `parent_id`, `title`, `name`, `alias`, `image`, `section`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `editor`, `ordering`, `access`, `count`, `params`, `contact_section`) VALUES
(1, 0, 'Division Information', '', 'division-information', '', '1', 'left', 'Information about the Southern Asia Division.', 1, 62, '2008-10-28 23:25:01', NULL, 1, 0, 0, '', NULL),
(2, 0, 'SDA Information', '', 'sda-info', '', '1', 'left', 'General information about Seventh-day Adventists.', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, '', NULL),
(3, 0, 'TestDirectory', '', 'testdirectory', '', 'com_qcontacts_details', 'left', 'None', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '', NULL),
(4, 0, 'Communication', '', 'department-of-communication', '', 'com_contact_details', 'left', 'The department of communication serves to make contact with the world to tell them about Jesus.', 1, 0, '0000-00-00 00:00:00', NULL, 2, 0, 0, '', 1),
(5, 0, 'Education', '', 'department-of-education', '', 'com_contact_details', 'left', 'The Department of Education exists to educate others about Jesus.', 1, 0, '0000-00-00 00:00:00', NULL, 3, 0, 0, '', 1),
(7, 0, 'Administrators', '', 'administrators', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '', 1),
(8, 0, 'Secretariat', '', 'secretariat', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 4, 0, 0, '', 1),
(13, 0, 'PARL', '', 'parl', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 9, 0, 0, '', 1),
(9, 0, 'Treasury', '', 'treasury', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 5, 0, 0, '', 1),
(10, 0, 'Children''s Ministries', '', 'child-ministries', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 6, 0, 0, '', 1),
(11, 0, 'Church Nurturing Ministries', '', 'church-nurturing-ministries', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 7, 0, 0, '', 1),
(12, 0, 'Chaplaincy', '', 'chaplaincy', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 8, 0, 0, '', 1),
(14, 0, 'Faith Development In Context', '', 'faith-development-in-context', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 10, 0, 0, '', 1),
(15, 0, 'Adventist Child India', '', 'adventist-child-india', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 11, 0, 0, '', 1),
(16, 0, 'Family', '', 'family', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 12, 0, 0, '', 1),
(17, 0, 'Youth', '', 'youth', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 13, 0, 0, '', 1),
(18, 0, 'Global Mission', '', 'global-mission', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 14, 0, 0, '', 1),
(19, 0, 'Health and Temperance', '', 'health-and-temperance', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 15, 0, 0, '', 1),
(20, 0, 'Stewardship', '', 'stewardship', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 16, 0, 0, '', 1),
(21, 0, 'Department of Legal Affairs', '', 'legal-affairs', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 17, 0, 0, '', 1),
(22, 0, 'Ministerial', '', 'ministerial', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 18, 0, 0, '', 1),
(23, 0, 'Publishing', '', 'publishing', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 19, 0, 0, '', 1),
(24, 0, 'Retirement Plan', '', 'retirement-plan', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 20, 0, 0, '', 1),
(25, 0, 'Sabbath School', '', 'sabbath-school', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 21, 0, 0, '', 1),
(26, 0, 'Personal Ministries', '', 'personal-ministries', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 22, 0, 0, '', 1),
(27, 0, 'Ministry to the Blind', '', 'ministry-to-the-blind', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 23, 0, 0, '', 1),
(28, 0, 'Special Ministries', '', 'special-ministries', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 24, 0, 0, '', 1),
(29, 0, 'TRUST Services', '', 'trust-services', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 25, 0, 0, '', 1),
(30, 0, 'Women''s Ministries', '', 'womens-ministries', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 26, 0, 0, '', 1),
(31, 0, 'Auditing Service', '', 'auditing-service', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 27, 0, 0, '', 1),
(32, 0, 'Southern Asia Tidings', '', 'southern-asia-tidings', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 28, 0, 0, '', 1),
(33, 0, 'Hinduism Study Center', '', 'hinduism-study-center', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 29, 0, 0, '', 1),
(34, 0, 'Spirit of Prophecy', '', 'spirit-of-prophecy', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 30, 0, 0, '', 1),
(35, 0, 'Satellite Evangelism', '', 'satellite-evangelism', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 31, 0, 0, '', 1),
(36, 0, 'Building', '', 'building', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 32, 0, 0, '', 1),
(37, 0, 'Adventist Risk Management', '', 'adventist-risk-management', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 33, 0, 0, '', 1),
(38, 0, 'Adventist Volunteer Service', '', 'adventist-volunteer-service', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 34, 0, 0, '', 1),
(39, 0, 'Adventist Media Centre', '', 'adventist-media-centre', '', 'com_contact_details', 'left', '<ul class="addressInformation">   <li>Post Box 1446, Marketyard</li>   <li>Pune 411 037,</li>   <li>Maharashtra</li>   <li><strong>Telephone</strong>:  (020) 2427 1483/24265450</li>   <li><strong>Fax</strong>:  (020) 2427 - 1483</li>   <li><strong>Email</strong>:<ul class="emails">            <li><a href="mailto:amc@pn2.vsnl.net.in">amc@pn2.vsnl.net.in</a></li>            <li><a href="mailto:amc3@vsnl.com">amc3@vsnl.com</a></li>            </ul>    </li>    </ul>', 1, 62, '2008-10-24 00:11:34', NULL, 35, 0, 0, '', 1),
(40, 0, 'Oriental Watchman Publishing House', '', 'oriental-watchman-publishing-house', '', 'com_contact_details', 'left', '<ul class="addressInformation">   <li>Post Box 1417, Salisbury Park</li>   <li>Pune 411 037</li>   <li><strong>Telephone</strong>: 91(020)242-614-41/242-730-17</li>   <li><strong>Fax</strong>: 91(020)242-616-38</li>   <li><strong>Email</strong>: <ul class="emails"><li>owph@pn2.vsnl.net.in</li></ul></li></ul>', 1, 62, '2008-10-24 00:39:41', NULL, 36, 0, 0, '', 1),
(41, 0, 'Intra Church Publications', '', 'intra-church-publications', '', 'com_contact_details', 'left', '<ul class="addressInformation"> <li>P O Box 1413</li> <li>Salisbury Park</li> <li>Pune 411 037</li> <li><strong>Telephone</strong>: 91(020)562-648-05</li> </ul>', 1, 0, '0000-00-00 00:00:00', NULL, 37, 0, 0, '', 1),
(42, 0, 'Legal Affairs', '', 'legal-affairs', '', 'com_contact_details', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 38, 0, 0, '', 1),
(43, 0, 'Unions', '', 'unions', '', '2', 'left', '', 1, 0, '0000-00-00 00:00:00', NULL, 1, 0, 0, '', NULL),
(45, 0, 'East - Central India Union', '', 'east-central-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>2 Chapel Road</li>\r\n  <li>Hyderabad 500 001</li>\r\n  <li>Andhra Pradesh</li>\r\n  <li><strong>Telephone</strong>: 91(040)232-018-32/232-000-79</li>\r\n  <li><strong>Fax</strong>:  (040)232-027-04</li>\r\n  <li><strong>E-mail</strong>:   \r\n    <ul class="emails">\r\n      <li>ciusda1@sify.com</li>\r\n    </ul>\r\n  </li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 39, 0, 0, '', 2),
(46, 0, 'Western India Union', '', 'western-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>Post Box 1413, Market Yard</li>\r\n  <li>Pune 411 037</li>\r\n  <li>Maharashtra</li>\r\n  <li><strong>Telephone</strong>:  91(020)242-718-96, 242-718-9</li>\r\n  <li><strong>Fax</strong>:  91(020)242-730-20</li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 40, 0, 0, '', 2),
(47, 0, 'Southwest India Union', '', 'southwest-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>B. No. 753, Evergreen Lane</li>\r\n  <li>Moospet Road</li>\r\n  <li>Thrissur 680 005</li>\r\n  <li>Kerala</li>\r\n  <li><strong>Telephone</strong>:  91(0487)244-0341, 244-0343</li>\r\n  <li><strong>Fax</strong>:  91(0487)-2440-343</li>\r\n  <li><strong>E-mail</strong>:  \r\n    <ul class="emails"><li>keusda@sancharnet.in</li></ul>\r\n  </li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 41, 0, 0, '', 2),
(48, 0, 'Southeast India Union', '', 'southeast-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>197 GST Road, Vandalur</li>\r\n  <li>Chennai 600 048</li>\r\n  <li>Tamil Nadu</li>\r\n  <li><strong>Telephone</strong>:  91(044)223-995-95, 223-995-96</li>\r\n  <li><strong>Fax</strong>:  91(044)223-996-52</li>\r\n  <li><strong>E-mail</strong>:  <ul class="emails"><li>siu_sda@vsnl.net</li></ul></li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 42, 0, 0, '', 2),
(49, 0, 'South - Central India Union', '', 'south-central-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>Spencer Road</li>\r\n  <li>Frazer Town</li>\r\n  <li>Bangalore 560 005</li>\r\n  <li>Karnataka</li>\r\n  <li><strong>Telephone</strong>:  91(080)255-671-27, 255-698-378</li>\r\n  <li><strong>Fax</strong>:  91(080)253-027-21</li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 43, 0, 0, '', 2),
(50, 0, 'Northern India Union', '', 'northern-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>11 Hailey Road</li>\r\n  <li>New Delhi 110 001</li>\r\n  <li><strong>Telephone</strong>:  91(011)233-249-59, 233-296-81</li>\r\n  <li><strong>Fax</strong>:  91(011)233-249-59</li>\r\n  <li><strong>E-mail</strong>:  <ul class="emails"><li>niusda@vsnl.com</li></ul></li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 44, 0, 0, '', 2),
(51, 0, 'Northeast India Union', '', 'northeast-india-union', '', 'com_contact_details', 'left', '<ul class="addressInformation">\r\n  <li>"Santana," Laitumkhrah</li>\r\n  <li>Shillong 793 003</li>\r\n  <li>Meghalaya</li>\r\n  <li><strong>Telephone</strong>:  91(0364)252-2471</li>\r\n  <li><strong>Fax</strong>:  91(0364)252-2471</li>\r\n  <li><strong>E-mail</strong>:  \r\n    <ul class="emails"><li>neiusda1@sancharnet.in</li></ul>\r\n  </li>\r\n</ul>', 1, 0, '0000-00-00 00:00:00', NULL, 45, 0, 0, '', 2),
(52, 0, 'The Developers', '', 'the-developers', '', 'com_contact_details', 'left', 'The illustrious people who work on this website.', 1, 0, '0000-00-00 00:00:00', NULL, 46, 0, 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_components`
--

DROP TABLE IF EXISTS `jos_components`;
CREATE TABLE IF NOT EXISTS `jos_components` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(50) NOT NULL default '',
  `link` varchar(255) NOT NULL default '',
  `menuid` int(11) unsigned NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `admin_menu_link` varchar(255) NOT NULL default '',
  `admin_menu_alt` varchar(255) NOT NULL default '',
  `option` varchar(50) NOT NULL default '',
  `ordering` int(11) NOT NULL default '0',
  `admin_menu_img` varchar(255) NOT NULL default '',
  `iscore` tinyint(4) NOT NULL default '0',
  `params` text NOT NULL,
  `enabled` tinyint(4) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `parent_option` (`parent`,`option`(32))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=54 ;

--
-- Dumping data for table `jos_components`
--

INSERT INTO `jos_components` (`id`, `name`, `link`, `menuid`, `parent`, `admin_menu_link`, `admin_menu_alt`, `option`, `ordering`, `admin_menu_img`, `iscore`, `params`, `enabled`) VALUES
(1, 'Banners', '', 0, 0, '', 'Banner Management', 'com_banners', 0, 'js/ThemeOffice/component.png', 0, 'track_impressions=0\ntrack_clicks=0\ntag_prefix=\n\n', 1),
(2, 'Banners', '', 0, 1, 'option=com_banners', 'Active Banners', 'com_banners', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(3, 'Clients', '', 0, 1, 'option=com_banners&c=client', 'Manage Clients', 'com_banners', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(4, 'Web Links', 'option=com_weblinks', 0, 0, '', 'Manage Weblinks', 'com_weblinks', 0, 'js/ThemeOffice/component.png', 0, 'show_comp_description=1\ncomp_description=\nshow_link_hits=1\nshow_link_description=1\nshow_other_cats=1\nshow_headings=1\nshow_page_title=1\nlink_target=0\nlink_icons=\n\n', 1),
(5, 'Links', '', 0, 4, 'option=com_weblinks', 'View existing weblinks', 'com_weblinks', 1, 'js/ThemeOffice/edit.png', 0, '', 1),
(6, 'Categories', '', 0, 4, 'option=com_categories&section=com_weblinks', 'Manage weblink categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(7, 'Contacts', 'option=com_contact', 0, 0, '', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/component.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=1\nshow_telephone=1\nshow_mobile=0\nshow_fax=0\nallow_vcard=0\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=1\ncustom_reply=0\n\n', 1),
(8, 'Contacts', '', 0, 7, 'option=com_contact', 'Edit contact details', 'com_contact', 0, 'js/ThemeOffice/edit.png', 1, '', 1),
(9, 'Categories', '', 0, 7, 'option=com_categories&section=com_contact_details', 'Manage contact categories', '', 2, 'js/ThemeOffice/categories.png', 1, 'contact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_fax=\nicon_misc=\nshow_headings=1\nshow_position=1\nshow_email=0\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nbannedEmail=\nbannedSubject=\nbannedText=\nsession=1\ncustomReply=0\n\n', 1),
(10, 'Polls', 'option=com_poll', 0, 0, 'option=com_poll', 'Manage Polls', 'com_poll', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(11, 'News Feeds', 'option=com_newsfeeds', 0, 0, '', 'News Feeds Management', 'com_newsfeeds', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(12, 'Feeds', '', 0, 11, 'option=com_newsfeeds', 'Manage News Feeds', 'com_newsfeeds', 1, 'js/ThemeOffice/edit.png', 0, 'show_headings=1\nshow_name=1\nshow_articles=1\nshow_link=1\nshow_cat_description=1\nshow_cat_items=1\nshow_feed_image=1\nshow_feed_description=1\nshow_item_description=1\nfeed_word_count=0\n\n', 1),
(13, 'Categories', '', 0, 11, 'option=com_categories&section=com_newsfeeds', 'Manage Categories', '', 2, 'js/ThemeOffice/categories.png', 0, '', 1),
(14, 'User', 'option=com_user', 0, 0, '', '', 'com_user', 0, '', 1, '', 1),
(15, 'Search', 'option=com_search', 0, 0, 'option=com_search', 'Search Statistics', 'com_search', 0, 'js/ThemeOffice/component.png', 1, 'enabled=0\n\n', 1),
(16, 'Categories', '', 0, 1, 'option=com_categories&section=com_banner', 'Categories', '', 3, '', 1, '', 1),
(17, 'Wrapper', 'option=com_wrapper', 0, 0, '', 'Wrapper', 'com_wrapper', 0, '', 1, '', 1),
(18, 'Mail To', '', 0, 0, '', '', 'com_mailto', 0, '', 1, '', 1),
(19, 'Media Manager', '', 0, 0, 'option=com_media', 'Media Manager', 'com_media', 0, '', 1, 'upload_extensions=bmp,csv,doc,epg,gif,ico,jpg,odg,odp,ods,odt,pdf,png,ppt,swf,txt,xcf,xls,BMP,CSV,DOC,EPG,GIF,ICO,JPG,ODG,ODP,ODS,ODT,PDF,PNG,PPT,SWF,TXT,XCF,XLS\nupload_maxsize=10000000\nfile_path=images\nimage_path=images/stories\nrestrict_uploads=1\ncheck_mime=1\nimage_extensions=bmp,gif,jpg,png\nignore_extensions=\nupload_mime=image/jpeg,image/gif,image/png,image/bmp,application/x-shockwave-flash,application/msword,application/excel,application/pdf,application/powerpoint,text/plain,application/x-zip\nupload_mime_illegal=text/html\nenable_flash=1\n\n', 1),
(20, 'Articles', 'option=com_content', 0, 0, '', '', 'com_content', 0, '', 1, 'show_noauth=0\nshow_title=1\nlink_titles=0\nshow_intro=1\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_item_navigation=0\nshow_readmore=1\nshow_vote=0\nshow_icons=1\nshow_pdf_icon=1\nshow_print_icon=1\nshow_email_icon=0\nshow_hits=0\nfeed_summary=0\nfilter_tags=\nfilter_attritbutes=\n\n', 1),
(21, 'Configuration Manager', '', 0, 0, '', 'Configuration', 'com_config', 0, '', 1, '', 1),
(22, 'Installation Manager', '', 0, 0, '', 'Installer', 'com_installer', 0, '', 1, '', 1),
(23, 'Language Manager', '', 0, 0, '', 'Languages', 'com_languages', 0, '', 1, '', 1),
(24, 'Mass mail', '', 0, 0, '', 'Mass Mail', 'com_massmail', 0, '', 1, 'mailSubjectPrefix=\nmailBodySuffix=\n\n', 1),
(25, 'Menu Editor', '', 0, 0, '', 'Menu Editor', 'com_menus', 0, '', 1, '', 1),
(27, 'Messaging', '', 0, 0, '', 'Messages', 'com_messages', 0, '', 1, '', 1),
(28, 'Modules Manager', '', 0, 0, '', 'Modules', 'com_modules', 0, '', 1, '', 1),
(29, 'Plugin Manager', '', 0, 0, '', 'Plugins', 'com_plugins', 0, '', 1, '', 1),
(30, 'Template Manager', '', 0, 0, '', 'Templates', 'com_templates', 0, '', 1, '', 1),
(31, 'User Manager', '', 0, 0, '', 'Users', 'com_users', 0, '', 1, 'allowUserRegistration=1\nnew_usertype=Registered\nuseractivation=1\nfrontend_userparams=1\n\n', 1),
(32, 'Cache Manager', '', 0, 0, '', 'Cache', 'com_cache', 0, '', 1, '', 1),
(33, 'Control Panel', '', 0, 0, '', 'Control Panel', 'com_cpanel', 0, '', 1, '', 1),
(40, 'Galleries', '', 0, 39, 'option=com_morfeoshow', 'Galleries', 'com_morfeoshow', 0, 'components/com_morfeoshow/images/gall.png', 0, '', 1),
(41, 'Configuration', '', 0, 39, 'option=com_morfeoshow&task=showSettings', 'Configuration', 'com_morfeoshow', 1, 'components/com_morfeoshow/images/conf.png', 0, '', 1),
(42, 'Info', '', 0, 39, 'option=com_morfeoshow&task=info', 'Info', 'com_morfeoshow', 2, 'components/com_morfeoshow/images/infor.png', 0, '', 1),
(39, 'MorfeoShow', 'option=com_morfeoshow', 0, 0, 'option=com_morfeoshow', 'MorfeoShow', 'com_morfeoshow', 0, 'components/com_morfeoshow/images/tool.png', 0, '', 1),
(52, 'Plugins', '', 0, 48, 'option=com_jce&type=plugin', 'Plugins', 'com_jce', 3, 'templates/khepri/images/menu/icon-16-plugin.png', 0, '', 1),
(49, 'Control Panel', '', 0, 48, 'option=com_jce', 'Control Panel', 'com_jce', 0, 'templates/khepri/images/menu/icon-16-cpanel.png', 0, '', 1),
(50, 'Configuration', '', 0, 48, 'option=com_jce&type=config', 'Configuration', 'com_jce', 1, 'templates/khepri/images/menu/icon-16-config.png', 0, '', 1),
(51, 'Groups', '', 0, 48, 'option=com_jce&type=group', 'Groups', 'com_jce', 2, 'templates/khepri/images/menu/icon-16-user.png', 0, '', 1),
(48, 'JCE Administration', 'option=com_jce', 0, 0, 'option=com_jce', 'JCE Administration', 'com_jce', 0, 'js/ThemeOffice/component.png', 0, '', 1),
(53, 'Install', '', 0, 48, 'option=com_jce&type=install', 'Install', 'com_jce', 4, 'templates/khepri/images/menu/icon-16-install.png', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_details`
--

DROP TABLE IF EXISTS `jos_contact_details`;
CREATE TABLE IF NOT EXISTS `jos_contact_details` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `con_position` varchar(255) default NULL,
  `address` text,
  `suburb` varchar(100) default NULL,
  `state` varchar(100) default NULL,
  `country` varchar(100) default NULL,
  `postcode` varchar(100) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `misc` mediumtext,
  `image` varchar(255) default NULL,
  `imagepos` varchar(20) default NULL,
  `email_to` varchar(255) default NULL,
  `default_con` tinyint(1) unsigned NOT NULL default '0',
  `published` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `mobile` varchar(255) NOT NULL default '',
  `webpage` varchar(255) NOT NULL default '',
  `first_name` varchar(128) NOT NULL default '',
  `last_name` varchar(128) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=125 ;

--
-- Dumping data for table `jos_contact_details`
--

INSERT INTO `jos_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `first_name`, `last_name`) VALUES
(2, 'Gordon Christo', 'dr-gordon-christo', 'Director', '', '', '', '', '', '91(0)944-3375-251', '', '', '', NULL, 'gechristo@sud-adventist.org', 0, 1, 62, '2008-10-28 16:14:32', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=0\nshow_suburb=0\nshow_state=0\nshow_postcode=0\nshow_country=0\nshow_telephone=1\nshow_mobile=0\nshow_fax=0\nshow_webpage=0\nshow_misc=0\nshow_image=0\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 4, 0, '', '', 'Gordon', 'Christo'),
(3, 'G Nageshwara  Rao', 'dr-gollakoti-nageshwar-rao-phd', 'Director', '', '', '', '', '', '91-(0)4344-263842', '', '', '', NULL, 'gnageshwarrao@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=0\nshow_suburb=0\nshow_state=0\nshow_postcode=0\nshow_country=0\nshow_telephone=1\nshow_mobile=0\nshow_fax=0\nshow_webpage=0\nshow_misc=0\nshow_image=0\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 5, 0, '91-(0)944-2645-345', '', 'G Nageshwara', 'Rao'),
(6, 'R John', 'r-john', NULL, '', '', '', '', '', '91-(0)944-3375-234', '', '', '', NULL, 'rjohn@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '', '', 'R', 'John'),
(15, 'Le Roy  Samuel', 'le-roy-samuel', NULL, '', '', '', '', '', '91-(0)944-2602-170', '', '', '', NULL, 'leroysamuel@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 9, 0, '', '', 'Le Roy', 'Samuel'),
(7, 'G S Robert Clive', 'g-s-robert-clive', NULL, '', '', '', '', '', '', '', '', '', NULL, 'gsrobertclive@sud-adventist.org', 0, 1, 62, '2008-10-27 19:08:38', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '', '', 'G S Robert', 'Clive'),
(8, 'M C John', 'm-c-john', NULL, '', '', '', '', '', '91-(0)944-2621-345', '', '', '', NULL, 'mcjohn@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '', '', 'M C', 'John'),
(9, 'R L Robinson', 'r-l-robinson', NULL, '', '', '', '', '', '91-(0)4344-263820', '', '', '', NULL, 'robertr@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '91-(0)944-3375-238', '', 'R L', 'Robinson'),
(10, 'Candy Zook', 'candy-zook', NULL, '', '', '', '', '', '91-(0)944-2631-345', '', '', '', NULL, 'cdzook52@yahoo.com', 0, 1, 62, '2008-10-27 23:03:59', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '', '', 'Candy', 'Zook'),
(11, 'Cyril Monthero', 'cyril-monthero', NULL, '', '', '', '', '', '91(0)944-8904-983', '', '', '', NULL, 'cyrilmonthero@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 8, 0, '', '', 'Cyril', 'Monthero'),
(12, 'G R Mohan Roy', 'g-r-mohan-roy', NULL, '', '', '', '', '', '', '', '', '', NULL, 'mohanroy@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 7, 0, '91-(0)4344-263819', '', 'G R Mohan', 'Roy'),
(13, 'Shamgar Prasada Rao', 'shamgar-prasada-rao', NULL, '', '', '', '', '', '91-(0)4344-263828', '', '', '', NULL, 'shamgarprao@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 8, 0, '91-(0)995-240-4943', '', 'Shamgar Prasada', 'Rao'),
(14, 'P E Selvin  Moorthy', 'p-e-selvin-moorthy', NULL, '', '', '', '', '', '91-(0)4344-263801', '', '', '', NULL, 'selvindmoorthy@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 9, 0, '91-(0)944-3375-229', '', 'P E Selvin', 'Moorthy'),
(16, 'Jothi J  Anbiah', 'jothi-j-anbiah', NULL, '', '', '', '', '', '91-(0)944-3375-240', '', '', '', NULL, 'jothianbiah@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 9, 0, '', '', 'Jothi J', 'Anbiah'),
(17, 'Brenda Robinson', 'brenda-robinson', NULL, '', '', '', '', '', '91-(0)4344-263822', '', '', '', NULL, 'brendar@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 9, 0, '91-(0)944-3375-239', '', 'Brenda', 'Robinson'),
(18, 'V P  Singh', 'v-p-singh', NULL, '', '', '', '', '', '91-(0)4344-263875', '', '', '', NULL, 'vpsingh@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 9, 0, '91-(0)944-2641-345', '', 'V P', 'Singh'),
(19, 'Paulraj  Isaiah', 'paulraj-isaiah', NULL, '', '', '', '', '', '91-(0)944-3375-260', '', '', '', NULL, 'paulrajisaiah@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 11, 0, '', '', 'Paulraj', 'Isaiah'),
(20, 'Ramani  Kurian', 'ramani-kurian', NULL, '', '', '', '', '', '', '', '', '', NULL, 'ramanikurian@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 5, 0, '', '', 'Ramani', 'Kurian'),
(21, 'T P  Kurian', 't-p-kurian', NULL, '', '', '', '', '', '91-(0)944-2647-234', '', '', '', NULL, 'tpkurian@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 14, 0, '', '', 'T P', 'Kurian'),
(22, 'Lionel F  Lyngdoh', 'lionel-f-lyngdoh', NULL, '', '', '', '', '', '91-(0)944-3375-228', '', '', '', NULL, 'lyngdoh@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 16, 0, '', '', 'Lionel F', 'Lyngdoh'),
(23, 'Ramesh Y  Jadhav', 'ramesh-y-jadhav', NULL, '', '', '', '', '', '91-(0)944-3375-236', '', '', '', NULL, 'jadhavry@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 18, 0, '', '', 'Ramesh Y', 'Jadhav'),
(24, 'M D  Joseph', 'm-d-joseph', NULL, '', '', '', '', '', '91-(0)948-666-5831', '', '', '', NULL, 'mdjoseph@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 19, 0, '', '', 'M D', 'Joseph'),
(25, 'Jayawant  Peter', 'jayawant-peter', NULL, '', '', '', '', '', '91-(0)4344-263879', '', '', '', NULL, 'jayawanthpeter@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 42, 0, '91-(0)944-3375-225', '', 'Jayawant', 'Peter'),
(26, 'Anita  Livingston', 'anita-livingston', NULL, '', '', '', '', '', '91-(0)995-2639-017', '', '', '', NULL, 'anital@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 42, 0, '', '', 'Anita', 'Livingston'),
(27, 'M Wilson', 'm-wilson', NULL, '', '', '', '', '', '91-(0)4344-263845', '', '', '', NULL, 'mwilson@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 22, 0, '91-(0)944-2644-234', '', 'M', 'Wilson'),
(28, 'A J  Tito', 'a-j-tito', NULL, '', '', '', '', '', '91-(0)4344-263861', '', '', '', NULL, 'tito@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 23, 0, '91-(0)944-3377-439', '', 'A J', 'Tito'),
(31, 'William  George', 'william-george', NULL, '', '', '', '', '', '91-(0)944-3375-233', '', '', '', NULL, 'williamgeorge@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 28, 0, '', '', 'William', 'George'),
(30, 'Ganaraj W  Kore', 'ganaraj-w-kore', NULL, '', '', '', '', '', '91-(0)944-3375-241', '', '', '', NULL, 'gnanarajkore@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 25, 0, '', '', 'Ganaraj W', 'Kore'),
(32, 'Ch Victor  Sam', 'ch-victor-sam', NULL, '', '', '', '', '', '91-(0)944-3375-246', '', '', '', NULL, 'victorsam@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 28, 0, '', '', 'Ch Victor', 'Sam'),
(46, 'Edison Samraj', 'edison-samraj', NULL, '', '', '', '', '', '91-(0)985-0426-704', '', '', '', NULL, 'e_samraj@vsnl.net', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 41, 0, '', '', 'Edison', 'Samraj'),
(34, 'Hepzibah  Kore', 'hepzibah-kore', NULL, '', '', '', '', '', '91-(0)944-3375-241', '', '', '', NULL, 'hepzibahkore@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 30, 0, '', '', 'Hepzibah', 'Kore'),
(35, 'Michael Prasada  Rao', 'michael-prasada-rao', NULL, '', '', '', '', '', '91-(0)4344-263815', '', '', '', NULL, 'michaelprao@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 31, 0, '91-(0)944-3377-592', '', 'Michael Prasada', 'Rao'),
(36, 'Jayaraj  Thangavelu', 'jayaraj-thangavelu', NULL, '', '', '', '', '', '91-(0)4344-263812', '', '', '', NULL, 'jayarajt@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 31, 0, '91-(0)944-3375-231', '', 'Jayaraj', 'Thangavelu'),
(37, 'Mathew  Devasahayam', 'mathew-devasahayam', NULL, '', '', '', '', '', '91(0)944-3375-232', '', '', '', NULL, 'mathewdevasahayam@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 31, 0, '', '', 'Mathew', 'Devasahayam'),
(38, 'Rosenita  Christo', 'rosenita-christo', NULL, '', '', '', '', '', '91-(0)944-3375-253', '', '', '', NULL, 'rosechristo@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 32, 0, '', '', 'Rosenita', 'Christo'),
(39, 'Margaret  Tito', 'margaret-tito', NULL, '', '', '', '', '', '', '', '', '', NULL, 'margaret@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 24, 0, '', '', 'Margaret', 'Tito'),
(40, 'John  Masefield', 'john-masefield', NULL, '', '', '', '', '', '91-(0)944-3375-227', '', '', '', NULL, 'johnmasefield@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 36, 0, '', '', 'John', 'Masefield'),
(41, 'John  Mathew', 'john-mathew', NULL, '', '', '', '', '', '91-(0)944-3375-243', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 36, 0, '', '', 'John', 'Mathew'),
(42, 'Flora John', 'flora-john', NULL, '', '', '', '', '', '', '', '', '', NULL, 'childcare@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 15, 0, '', '', 'Flora', 'John'),
(43, 'Rachel  John', 'rachel-john', NULL, '', '', '', '', '', '', '', '', '', NULL, 'acioffice@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 15, 0, '', '', 'Rachel', 'John'),
(44, 'Edwin  Charles', 'edwin-charles', NULL, '', '', '', '', '', '91-(0)94-225-036-02', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 39, 0, '', '', 'Edwin', 'Charles'),
(45, 'Edwin B Matthews', 'edwin-b-matthews', NULL, '', '', '', '', '', '91-(0)942-2305-808/91(020)242-650-70', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 40, 0, '', '', 'Edwin B', 'Matthews'),
(47, 'Ch John', 'ch-john', NULL, '', '', '', '', '', '91-(0)984-8129-551/232-018-32', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Ch', 'John'),
(48, 'M D Edward', 'm-d-edward', NULL, '', '', '', '', '', '91-(0)984-8751-781', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'M D', 'Edward'),
(49, 'D Alfred  Raju', 'd-alfred-raju', NULL, '', '', '', '', '', '91-(0)984-811-0006', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'D Alfred', 'Raju'),
(50, 'Pilli Edward Prasad', 'pilli-edward-prasad', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Pilli Edward', 'Prasad'),
(51, 'Davy Sudhakar', 'davy-sudhakar', NULL, '', '', '', '', '', '91-(0)988-5499-825', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Davy', 'Sudhakar'),
(107, 'Sosamma Varghese', 'sosamma-varghese', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'Sosamma', 'Varghese'),
(53, 'Ch Prabhakar  Rao', 'ch-prabhakar-rao', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Ch Prabhakar', 'Rao'),
(54, 'Ch Samuel Paul', 'ch-samuel-paul', NULL, '', '', '', '', '', '91-(0)944-0169-053', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Ch Samuel', 'Paul'),
(55, 'T Robinson Bob', 't-robinson-bob', NULL, '', '', '', '', '', '91-(0)986-6161-356', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'T Robinson', 'Bob'),
(56, 'Ch Vinodhini  John', 'ch-vinodhini-john', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 10, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Ch Vinodhini', 'John'),
(57, 'Madhuramani Wilbert', 'madhuramani-wilbert', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 11, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'Madhuramani', 'Wilbert'),
(58, 'K R Jones', 'k-r-jones', NULL, '', '', '', '', '', '91-(0)998-926-5077', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 12, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'K R', 'Jones'),
(59, 'J G Paulson', 'j-g-paulson', NULL, '', '', '', '', '', '91-(0)984-814-4278', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 13, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 45, 0, '', '', 'J G', 'Paulson'),
(60, 'L C Colney', 'l-c-colney', NULL, '', '', '', '', '', '91-(0)943-6117-829/ 252-1337', '', '', '', NULL, 'neiupre@sancharnet.in', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'L C', 'Colney'),
(61, 'C C Dkhar', 'c-c-dkhar', NULL, '', '', '', '', '', '91-(0)943-6105-626/252-1975', '', '', '', NULL, 'neiusecretary@yahoo.com', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'C C', 'Dkhar'),
(62, 'S K Archete', 's-k-archete', NULL, '', '', '', '', '', '91-(0)943-6116-752/ 252-0547', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'S K', 'Archete'),
(63, 'Mabel V Dkhar', 'mabel-v-dkhar', NULL, '', '', '', '', '', '91-(0)986-3023-109', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'Mabel V', 'Dkhar'),
(64, 'Barnabas Zimik', 'barnabas-zimik', NULL, '', '', '', '', '', '91-(0)986-311-517', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'Barnabas', 'Zimik'),
(65, 'Zohruaia Renthlei', 'zohruaia-renthlei', NULL, '', '', '', '', '', '91-(0)943-6111-188/250-1405', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'Zohruaia', 'Renthlei'),
(66, 'Ramsangpuii Colney', 'ramsangpuii-colney', NULL, '', '', '', '', '', '91-(0)943-630-4193/252-1337', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'Ramsangpuii', 'Colney'),
(67, 'R Rabha', 'r-rabha', NULL, '', '', '', '', '', '91-(0)986-214-4744', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 51, 0, '', '', 'R', 'Rabha'),
(105, 'P H Paulson', 'p-h-paulson', NULL, '', '', '', '', '', '91-(0)989-5691-844', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'P H', 'Paulson'),
(69, 'Hidayat Masih', 'hidayat-masih', NULL, '', '', '', '', '', '91-(0)981-1382-966', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Hidayat', 'Masih'),
(70, 'Ezras Lakra', 'ezras-lakra', NULL, '', '', '', '', '', '91-(0)981-1387-344', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Ezras', 'Lakra'),
(71, 'Alamgir Khan', 'alamgir-khan', NULL, '', '', '', '', '', '91-(0)981-1313-558', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Alamgir', 'Khan'),
(72, 'Veena Gayen', 'veena-gayen', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Veena', 'Gayen'),
(73, 'S B Bairagi', 's-b-bairagi', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'S B', 'Bairagi'),
(74, 'Benedict Biswas', 'benedict-biswas', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Benedict', 'Biswas'),
(75, 'Premila Masih', 'premila-masih', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'Premila', 'Masih'),
(104, 'S Stanley', 's-stanley', NULL, '', '', '', '', '', '91-(0)944-6141-822/244-6523', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'S', 'Stanley'),
(77, 'S R Bhatti', 's-r-bhatti', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 50, 0, '', '', 'S R', 'Bhatti'),
(78, 'Daniel Padmaraj', 'daniel-padmaraj', NULL, '', '', '', '', '', '91-(0)984-5003-077/253-650-92', '', '', '', NULL, 'sciu_president@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Daniel', 'Padmaraj'),
(79, 'D Jeyadev', 'd-jeyadev', NULL, '', '', '', '', '', '91-(0)998-6459-183/254-912-52', '', '', '', NULL, 'sciu_execsecretary@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'D', 'Jeyadev'),
(80, 'Edwin Stanley', 'edwin-stanley', NULL, '', '', '', '', '', '91-(0)944-8356-527/253-027-21/256-527-431', '', '', '', NULL, 'sciu_treasurer@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Edwin', 'Stanley'),
(81, 'Johnson Abraham', 'johnson-abraham', NULL, '', '', '', '', '', '91-(0)984-4068-766', '', '', '', NULL, 'sciu_assoctre@vsnl.net', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Johnson', 'Abraham'),
(82, 'Ranjan D', 'ranjan-d', NULL, '', '', '', '', '', '91-(0)944-8055-890', '', '', '', NULL, 'sciu_asstreasurer@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Ranjan', 'D'),
(83, 'Ravindra Shankar', 'ravindra-shankar', NULL, '', '', '', '', '', '91-(0)944-8355-255', '', '', '', NULL, 'sciu_ravindrashankar@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Ravindra', 'Shankar');
INSERT INTO `jos_contact_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `first_name`, `last_name`) VALUES
(84, 'Swamidas David', 'swamidas-david', NULL, '', '', '', '', '', '91-(0)990-0161-692', '', '', '', NULL, 'sciu_swamidas@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Swamidas', 'David'),
(85, 'Robert Donald', 'robert-donald', NULL, '', '', '', '', '', '(080)255-415-22; 91(0)944-9764-408', '', '', '', NULL, 'sciu_robertdonald@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Robert', 'Donald'),
(87, 'Philip Shekar', 'philip-shekar', NULL, '', '', '', '', '', '91(0)988-6990-647', '', '', '', NULL, 'sciu_philipshekar@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Philip', 'Shekar'),
(88, 'D Jayadev', 'd-jayadev', NULL, '', '', '', '', '', '91(0)998-6459-183/254-912-52', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 10, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'D', 'Jayadev'),
(89, 'S Shantha Kumar', 's-shantha-kumar', NULL, '', '', '', '', '', '91(0)988-0697-691', '', '', '', NULL, 'sciu_shanthapdd@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 11, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'S Shantha', 'Kumar'),
(90, 'Eileen Padmaraj', 'eileen-padmaraj', NULL, '', '', '', '', '', '91(080)253-650-92; 0988-0545-279', '', '', '', NULL, 'sciu_eileen08@yahoo.co.in', 0, 1, 0, '0000-00-00 00:00:00', 12, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 49, 0, '', '', 'Eileen', 'Padmaraj'),
(91, 'S Sundaram', 's-sundaram', NULL, '', '', '', '', '', '91-(0) 944-4059-532/044-223-996-51/223-919-09', '', '', '', NULL, '', 0, 1, 62, '2008-10-30 00:57:44', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'S', 'Sundaram'),
(92, 'Daniel Devadhas', 'daniel-devadhas', NULL, '', '', '', '', '', '91-(0)944-4044-302/044-223-996-52/223-943-02', '', '', '', NULL, 'pr-daniel@sify.com', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'Daniel', 'Devadhas'),
(93, 'Enoch Manickam', 'enoch-manickam', NULL, '', '', '', '', '', '91-(0)944-4064-433/044-223-996-53/223-82961', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'Enoch', 'Manickam'),
(94, 'S Antony Das', 's-antony-das', NULL, '', '', '', '', '', '91-(0)984-2115-54', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'S Antony', 'Das'),
(95, 'Manthri Moses', 'manthri-moses', NULL, '', '', '', '', '', '91-(0)944-4212-870/044-224-115-13', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'Manthri', 'Moses'),
(96, 'Premila Jayachandran', 'premila-jayachandran', NULL, '', '', '', '', '', '91-(0)994-4317-835/0413-222-3248', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'Premila', 'Jayachandran'),
(97, 'R Rajamani Muthu', 'r-rajamani-muthu', NULL, '', '', '', '', '', '044-994-0253-761', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'R Rajamani', 'Muthu'),
(98, ' Anothindhas', '-anothindhas', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', '', 'Anothindhas'),
(99, 'V M Arokiasamy', 'v-m-arokiasamy', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'V M', 'Arokiasamy'),
(100, 'Jones Rajarathinam', 'jones-rajarathinam', NULL, '', '', '', '', '', '91-(0)944-3194-573', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 10, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'Jones', 'Rajarathinam'),
(106, 'P T Johnkutty', 'p-t-johnkutty', NULL, '', '', '', '', '', '91-(0)944-7836-637', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'P T', 'Johnkutty'),
(102, 'M Anbalagan', 'm-anbalagan', NULL, '', '', '', '', '', '91-(0)938-260-7567', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 12, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'M', 'Anbalagan'),
(103, 'D Lingan', 'd-lingan', NULL, '', '', '', '', '', '91(0)944-4405-850/262-118-10', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 13, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 48, 0, '', '', 'D', 'Lingan'),
(108, 'K J Varghese', 'k-j-varghese', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'K J', 'Varghese'),
(109, 'Mary Thomas', 'mary-thomas', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'Mary', 'Thomas'),
(110, 'V K Baby', 'v-k-baby', NULL, '', '', '', '', '', '91-(0)989-5164-020', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'V K', 'Baby'),
(111, 'K N Varghese', 'k-n-varghese', NULL, '', '', '', '', '', '91-(0)989-5434-303', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'K N', 'Varghese'),
(112, 'Philip S Jacob', 'philip-s-jacob', NULL, '', '', '', '', '', '91-(0487)-2254-294', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'Philip S', 'Jacob'),
(113, 'Raju Abraham', 'raju-abraham', NULL, '', '', '', '', '', '91-(0)944-7068-641', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 10, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 47, 0, '', '', 'Raju', 'Abraham'),
(114, 'Gibeon E Sharon', 'gibeon-e-sharon', NULL, '', '', '', '', '', '91-(0)989-0112-637', '', '', '', NULL, 'prewiu@vsnl.net', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Gibeon E', 'Sharon'),
(115, 'Pratap Gaikwad', 'pratap-gaikwad', NULL, '', '', '', '', '', '91-(0)989-0116-902', '', '', '', NULL, 'secwiu@vsnl.net', 0, 1, 0, '0000-00-00 00:00:00', 2, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Pratap', 'Gaikwad'),
(116, 'Sukendu K Sircar', 'sukendu-k-sircar', NULL, '', '', '', '', '', '91-(0)989-0183-637', '', '', '', NULL, 'trewiu@vsnl.net', 0, 1, 0, '0000-00-00 00:00:00', 3, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Sukendu K', 'Sircar'),
(117, 'Rakesh Chavan', 'rakesh-chavan', NULL, '', '', '', '', '', '91-(0)982-2815-118', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 4, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Rakesh', 'Chavan'),
(119, 'Chandrakanth R Shinge', 'chandrakanth-r-shinge', NULL, '', '', '', '', '', '91-(0)989-0113-478', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 5, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Chandrakanth R', 'Shinge'),
(120, 'Prakash Sharma', 'prakash-sharma', NULL, '', '', '', '', '', '91-(0)989-0116-710', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 6, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Prakash', 'Sharma'),
(121, 'Ashirwad Pandey', 'ashirwad-pandey', NULL, '', '', '', '', '', '91-(0)986-0342-605', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 7, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Ashirwad', 'Pandey'),
(122, 'Zarin G Sharon', 'zarin-g-sharon', NULL, '', '', '', '', '', '', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 8, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Zarin G', 'Sharon'),
(123, 'Rajan Kedas', 'rajan-kedas', NULL, '', '', '', '', '', '91-(0)982-2271-214', '', '', '', NULL, '', 0, 1, 0, '0000-00-00 00:00:00', 9, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 0, 46, 0, '', '', 'Rajan', 'Kedas'),
(124, 'Steven Oxley', 'steven-oxley', NULL, '', '', '', '', '', '', '', '', '', NULL, 'xonev@hotmail.com', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_webpage=1\nshow_misc=1\nshow_image=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_email_form=1\nemail_description=\nshow_email_copy=1\nbanned_email=\nbanned_subject=\nbanned_text=', 62, 52, 0, '', '', 'Steven', 'Oxley');

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_positions`
--

DROP TABLE IF EXISTS `jos_contact_positions`;
CREATE TABLE IF NOT EXISTS `jos_contact_positions` (
  `id` int(11) NOT NULL auto_increment,
  `contact_id` int(11) NOT NULL default '0',
  `department_id` int(11) NOT NULL default '0',
  `position` varchar(255) NOT NULL default '',
  `ordering` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=151 ;

--
-- Dumping data for table `jos_contact_positions`
--

INSERT INTO `jos_contact_positions` (`id`, `contact_id`, `department_id`, `position`, `ordering`) VALUES
(1, 1, 4, 'Volunteer', NULL),
(2, 2, 4, 'Director', NULL),
(3, 3, 5, 'Director', NULL),
(8, 6, 7, 'President', 1),
(5, 0, 4, 'Editor', NULL),
(9, 7, 7, 'Treasurer', 9),
(10, 8, 7, 'General Vice President', 2),
(11, 2, 7, 'General Vice President', 3),
(12, 9, 7, 'Administrative Assistant to the President for Development', 5),
(13, 10, 7, 'Administrative Assistant to the President for Development', 6),
(14, 11, 8, 'Associate Secretary', NULL),
(15, 12, 7, 'Administrative Assistant to the President', 4),
(16, 13, 8, 'Associate Secretary', NULL),
(17, 14, 9, 'Under-treasurer', NULL),
(18, 10, 15, 'Director', NULL),
(19, 15, 9, 'Associate Treasurer', NULL),
(20, 16, 9, 'Associate Treasurer', NULL),
(21, 17, 9, 'Associate Treasurer', NULL),
(22, 18, 9, 'Associate Treasurer', NULL),
(23, 8, 10, 'Director', NULL),
(24, 19, 11, 'Director', NULL),
(25, 19, 12, 'Director', NULL),
(26, 2, 13, 'Director', NULL),
(27, 20, 5, 'Assistant', NULL),
(28, 21, 14, 'Director', NULL),
(29, 21, 15, 'Field Representative', NULL),
(30, 22, 16, 'Director', NULL),
(31, 22, 17, 'Director', NULL),
(32, 23, 18, 'Director', NULL),
(33, 24, 19, 'Director', NULL),
(34, 24, 20, 'Director', NULL),
(35, 25, 42, 'Director', NULL),
(36, 26, 42, 'Director', NULL),
(37, 27, 22, 'Director', NULL),
(38, 28, 23, 'Director', NULL),
(39, 29, 24, 'Director', NULL),
(40, 30, 25, 'Director', NULL),
(41, 30, 26, 'Director', NULL),
(42, 30, 27, 'Director', NULL),
(43, 16, 24, 'Director', NULL),
(44, 31, 28, 'Director', NULL),
(45, 32, 28, 'Director', NULL),
(46, 33, 29, 'Director', NULL),
(47, 34, 30, 'Director', NULL),
(48, 34, 22, 'Coordinator', NULL),
(49, 35, 31, 'Director', NULL),
(50, 36, 31, 'Associate Director', NULL),
(51, 37, 31, 'Assistant Director', NULL),
(52, 38, 32, 'Editor', NULL),
(53, 12, 33, 'Director', NULL),
(54, 19, 34, 'Director', NULL),
(55, 39, 24, 'Assistant Director', NULL),
(56, 2, 35, 'Coordinator', NULL),
(57, 40, 36, 'Engineer', NULL),
(58, 41, 36, 'Assistant Engineer', NULL),
(59, 15, 37, 'Director', NULL),
(60, 42, 15, 'Correspondent', NULL),
(61, 43, 15, 'Administrative Assistant to Candy Zook', NULL),
(62, 38, 38, 'Coordinator', NULL),
(63, 44, 39, 'Director', NULL),
(64, 45, 40, 'General Manager', NULL),
(65, 13, 29, 'Director', NULL),
(66, 46, 41, 'Manager', NULL),
(67, 11, 7, 'Associate Secretary', 7),
(68, 13, 7, 'Associate Secretary', 8),
(69, 14, 7, 'Under-treasurer', 10),
(70, 18, 7, 'Associate Treasurer', 11),
(71, 16, 7, 'Associate Treasurer', 12),
(72, 17, 7, 'Associate Treasurer', 13),
(73, 47, 45, 'President', NULL),
(74, 48, 45, 'Secretary', NULL),
(75, 49, 45, 'Treasurer', NULL),
(76, 50, 45, 'Associate Treasurer', NULL),
(77, 51, 45, 'Assistant Secretary', NULL),
(78, 52, 45, 'Comm/PARL/Spirit of Prophecy', NULL),
(79, 53, 45, 'Deaf Ministry', NULL),
(80, 54, 45, 'Education', NULL),
(81, 55, 45, 'Publishing', NULL),
(82, 56, 45, 'Shepherdess/ Women’s Min./Chm/Fly Ministries', NULL),
(83, 57, 45, 'Assoc. Director', NULL),
(84, 58, 45, 'WM/Stewardship/Nurturing  & Health', NULL),
(85, 59, 45, 'SS & PM/ Youth', NULL),
(86, 60, 51, 'President', NULL),
(87, 61, 51, 'Secretary', NULL),
(88, 62, 51, 'Treasurer', NULL),
(89, 63, 51, 'Edn Assoc. / Chm & W Min.', NULL),
(90, 64, 51, 'Fly /G M/ Pub. / Youth', NULL),
(91, 65, 51, 'Heath/ Stew/SS & PM', NULL),
(92, 66, 51, 'Shepherdess Intl Co-coordinator', NULL),
(93, 67, 51, 'Statistical Reports', NULL),
(94, 68, 51, 'Trust Services/ IFA', NULL),
(95, 69, 50, 'President', NULL),
(96, 70, 50, 'Secretary', NULL),
(97, 71, 50, 'Treasurer', NULL),
(98, 72, 50, 'Chm / Family/ W Min.', NULL),
(99, 73, 50, 'Ministerial Association', NULL),
(100, 74, 50, 'Publishing/ SS / PM', NULL),
(101, 75, 50, 'Shepherdess International', NULL),
(102, 76, 50, 'Spl Min./SOP/Youth', NULL),
(103, 77, 50, 'Stewardship/ Health Ministries', NULL),
(104, 78, 49, 'President', NULL),
(105, 79, 49, 'Secretary', NULL),
(106, 80, 49, 'Treasurer', NULL),
(107, 81, 49, 'Associate Treasurer', NULL),
(108, 82, 49, 'Asst. Treasurer/Church Audit', NULL),
(109, 83, 49, 'Comm/Youth/S S & P M/Health & Temp.', NULL),
(110, 84, 49, 'Education', NULL),
(111, 85, 49, 'Field Secretary & Nurturing/SOP/Trust Services', NULL),
(112, 86, 49, 'IFA &  Risk Management', NULL),
(113, 87, 49, 'Minl/ GM/ Stw/Home Fly/ Children Ministries', NULL),
(114, 88, 49, 'PARL/ADRA/Legal', NULL),
(115, 89, 49, 'Publishing', NULL),
(116, 90, 49, 'Women’s/ Shepherdess Intl', NULL),
(117, 91, 48, 'President', NULL),
(118, 92, 48, 'Secretary', NULL),
(119, 93, 48, 'Treasurer', NULL),
(120, 94, 48, 'Assoc. Secretary', NULL),
(121, 95, 48, 'Assoc. Treasurer', NULL),
(122, 96, 48, 'Chm/Home/Family', NULL),
(123, 97, 48, 'Communication/SS/PM', NULL),
(124, 98, 48, 'Health Ministries', NULL),
(125, 99, 48, 'Min./SOP/Nurt &Spl Min.', NULL),
(126, 100, 48, 'Music Ministries', NULL),
(127, 101, 48, 'PARL', NULL),
(128, 102, 48, 'President', NULL),
(129, 103, 48, 'Secretary', NULL),
(130, 104, 47, 'President', NULL),
(131, 105, 47, 'Secretary', NULL),
(132, 106, 47, 'Treasurer', NULL),
(133, 107, 47, 'ChM & Communication', NULL),
(134, 108, 47, 'Field Secretary/SS/PM/Youth', NULL),
(135, 109, 47, 'Family & WM', NULL),
(136, 110, 47, 'Ministerial, Stw. Publishing & Spl Min./Deaf & Dumb', NULL),
(137, 111, 47, 'Zonal Education Officer I', NULL),
(138, 112, 47, 'Zonal Education Officer II', NULL),
(139, 113, 47, 'Zonal Education Officer III', NULL),
(140, 114, 46, 'President', NULL),
(141, 115, 46, 'Secretary', NULL),
(142, 116, 46, 'Treasurer', NULL),
(143, 117, 46, 'Asst. Treasurer', NULL),
(144, 118, 46, 'Education', NULL),
(145, 119, 46, 'Ministerial Association', NULL),
(146, 120, 46, 'Publishing/Health/Comm', NULL),
(147, 121, 46, 'S S &  Personal Ministries', NULL),
(148, 122, 46, 'Women’s/ Shep. & ChMin', NULL),
(149, 123, 46, 'Stewardship', NULL),
(150, 124, 52, 'Lead (Only) Developer', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `jos_contact_sections`
--

DROP TABLE IF EXISTS `jos_contact_sections`;
CREATE TABLE IF NOT EXISTS `jos_contact_sections` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `jos_contact_sections`
--

INSERT INTO `jos_contact_sections` (`id`, `name`) VALUES
(1, 'Southern Asia Division'),
(2, 'Unions'),
(3, 'Developers');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content`
--

DROP TABLE IF EXISTS `jos_content`;
CREATE TABLE IF NOT EXISTS `jos_content` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `title_alias` varchar(255) NOT NULL default '',
  `introtext` mediumtext NOT NULL,
  `fulltext` mediumtext NOT NULL,
  `state` tinyint(3) NOT NULL default '0',
  `sectionid` int(11) unsigned NOT NULL default '0',
  `mask` int(11) unsigned NOT NULL default '0',
  `catid` int(11) unsigned NOT NULL default '0',
  `created` datetime NOT NULL default '0000-00-00 00:00:00',
  `created_by` int(11) unsigned NOT NULL default '0',
  `created_by_alias` varchar(255) NOT NULL default '',
  `modified` datetime NOT NULL default '0000-00-00 00:00:00',
  `modified_by` int(11) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_up` datetime NOT NULL default '0000-00-00 00:00:00',
  `publish_down` datetime NOT NULL default '0000-00-00 00:00:00',
  `images` text NOT NULL,
  `urls` text NOT NULL,
  `attribs` text NOT NULL,
  `version` int(11) unsigned NOT NULL default '1',
  `parentid` int(11) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `access` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0',
  `metadata` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_section` (`sectionid`),
  KEY `idx_access` (`access`),
  KEY `idx_checkout` (`checked_out`),
  KEY `idx_state` (`state`),
  KEY `idx_catid` (`catid`),
  KEY `idx_createdby` (`created_by`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `jos_content`
--

INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(1, 'Welcome', 'welcome', '', '<font color="#777777">Welcome to the Southern Asia Division of Seventh-day Adventists home page! It is a delight to have you visit us. We hope that this website will give you helpful information, answer your questions, and provide you with an overview of who we are and what we are about.  We are a family of committed believers in Jesus Christ, living expectantly in the light of His love and His coming, and seeking to serve the world around us. We would be delighted to have you visit us in person! May God bless you this day and every day.</font>', '', 1, 1, 0, 1, '2008-10-06 22:57:20', 62, '', '2008-10-31 06:28:56', 62, 0, '0000-00-00 00:00:00', '2008-10-06 22:57:20', '0000-00-00 00:00:00', '', '', 'show_title=1\nlink_titles=0\nshow_intro=0\nshow_section=0\nlink_section=0\nshow_category=0\nlink_category=0\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=0\nshow_print_icon=0\nshow_email_icon=0\nlanguage=\nkeyref=\nreadmore=', 4, 0, 2, '', '', 0, 0, 'robots=\nauthor='),
(2, 'Contact Us', 'contact-us', '', '<div style="text-align: left;"></div>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Contact Us:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">For inquiries, comments, and suggestions about the website, please contact:</p>\r\n<p><a href="http://adventist.org.in/index.php?option=com_contact&view=contact&id=124">Steven Oxley</a></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Postal Address:</p>\r\n<p style="margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">P.O. Box 2, Jeevan Jyothi Campus,</p>\r\n<p style="margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Hosur – 635110, Tamil Nadu, India</p>\r\n<p style="margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Tel: +91-4344-262171/72/73/74/75</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Fax: +91-4344-262090</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Directions:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Southern Asia Division can be easily reached by automobile and  				by public transportation from bus, train, and air. It is located  				in 				Hosur which is on the NH-7.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Distance from Key Towns: </strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Bangalore - 40 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Tiruchirapalli  - 350 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Chennai  - 350 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">To reach the Division Headquarters follow the directions below.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>By Car:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em>From Bangalore: </em>Follow the NH-7 on the Hosur Road. Turn right at Attibele and follow the signs for  				TVS factory. Keep going, following the main road past the  				Seventh-day Adventist School. Make a left at the next  				crossing. The Division Office is almost immediately on the right.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em>From Chennai: </em>Drive on the NH-46 through this route, Sriperumbudur, Kanchi (Outskirts), Ranipet, Vellore, Ambur,  				Vaniyambadi. Near Krishnagiri, join the NH-7 to Hosur. Turn left just before the Hosur bus stand and proceed  				through the city past the Hosur Railway Station and further 3 kms.  				The Division Office is on the left, just past the temple.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>By Bus:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em>From Bangalore: </em><strong>Majestic Bus Stand</strong> also known as the Kempegowda bus stand  				near Gandhi Nagar is close to the railway station and is quite  				neatly organized and is easily navigable. There is an inquiry  				office near platform number 1 on ‘Majestic’ where you can ask  				the bus number and platform for your desired destination. You  				can find a large map on display, which you can use to find the  				bus number you need to take if you know the area you are going  				to. You can of course always ask the conductor or other  				passengers. Route maps are also sold on the platforms. Take any  				bus going to the any of the following places Hosur, Salem,  				Krishnagiri, Vellore or Chennai. Get down at the <strong>Hosur Bus  				Stand</strong>.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em>From Chennai: </em>The inter city bus station called called <strong> Chennai Mofussil Bus Terminus (CMBT)</strong> has the distinction of  				being the largest in the whole South Asian region. Take any bus  				to Hosur or Bangalore. Get down at the <strong>Hosur Bus Stand</strong>.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Take an auto (Rs. 35-40) to the Seventh-day Adventist Campus, or  				take a local bus (Rs. 3) that goes towards Mathigiri or  				Denkanikottai and get down at the ITI stop. Walk straight down,  				the Division Office is on the right, left past the temple.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>By Train:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">There are local and express trains from Bangalore everyday. You  				can ask the enquiry at the station to find out train timings and  				routes. Alternatively you can check 				<a href="http://www.southernrailway.org/" title="Southern Railways">Southern Railways</a> website.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em> <strong>Nearest Major Railway Station: </strong></em></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Hosur Junction</strong> - 3 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>By Air:</strong></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">There are local flights to Bangalore from anywhere in India.  				Also you can take an international flight to Bangalore or  				Chennai. Ask your local travel agent for more information on  				flight details.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><em> <strong>Nearest Airports: </strong></em></p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Bangalore Airport (BLR)</strong> - 35 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Take a taxi, train or bus from Bangalore to Hosur.</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"> </p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal"><strong>Anna International Airport, Chennai</strong> - 340 kms</p>\r\n<p style="text-align: justify; margin-top: 0pt; margin-bottom: 0pt" class="MsoNormal">Take a taxi, train or bus from Chennai to Hosur.</p>', '', 1, 1, 0, 1, '2008-10-06 22:59:36', 62, '', '2008-10-31 07:26:18', 62, 0, '0000-00-00 00:00:00', '2008-10-06 22:59:36', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=0\nshow_author=0\nshow_create_date=0\nshow_modify_date=0\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 1, '', '', 0, 30, 'robots=\nauthor='),
(3, 'About Us', 'about-us', '', '<p>We are a family of committed believers in Jesus Christ, living expectantly in the light of his love and his coming, and seeking to serve the world around us.</p><p style="margin-top: 0pt; margin-bottom: 0pt" class="text" align="justify"><strong>Additional Information:</strong></p> 				<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/mission.html">Mission & Vision</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/logo.html">Logo</a></p><ul><li> 					<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 					<a href="http://www.adventist.org.in/About%20Us/churchname.html">Use of the Church Name</a> 					</p></li><li> 					<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 					<a href="http://www.adventist.org.in/About%20Us/churchname.html">Guidelines for Seventh-day  					Adventist Church Websites</a> 					</p></li><li> 					<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 					<a href="http://www.adventist.org.in/About%20Us/trademark.html">Seventh-day Adventist Trademark  					Guidelines</a> 				</p></li></ul> 				<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/quicklook.html">A Quick Look at the Seventh-day  				Adventist Church</a></p> 				<p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/briefhistory.html">A Brief History of the Seventh-day  				Adventist Church</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/assortedfacts.htm">Assorted Facts about Adventists and  				their Church</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/history.html">History</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/whatwebelieve.html">What We Believe</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/fundamentalbeliefs.html">Fundamental Beliefs</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/neighbour.html">Your Seventh-day Adventist Neighbour</a></p><p style="margin-top: 0pt; margin-bottom: 0pt" align="justify"> 				<a href="http://www.adventist.org.in/About%20Us/org.html">Organizational Structure</a></p><p>&nbsp;</p>', '', -2, 1, 0, 1, '2008-10-07 00:01:31', 62, '', '2008-10-07 00:04:57', 62, 0, '0000-00-00 00:00:00', '2008-10-07 00:01:31', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 0, '', '', 0, 3, 'robots=\nauthor='),
(4, 'Mission Statement of the Seventh-day Adventist Church', 'mission', '', '<p><strong>Our Mission</strong>: The mission of the Seventh-day Adventist Church is to proclaim to all peoples the everlasting gospel in the context of the three angels’ messages of Revelation 14:6-12, leading them to accept Jesus as personal Saviour and to unite with His church, and nurturing them in preparation for His soon return. </p> <p> <strong>Our Method</strong>: We pursue this mission under the guidance of the Holy Spirit through: </p><ol>   <li><em>Preaching </em>– Accepting Christ’s commission (Matt 28:18-20), we proclaim to all the world the message of a loving God, most fully revealed in His Son’s reconciling ministry and atoning death. Recognizing the Bible to be God’s infallible revelation of His will, we present its full message, including the second advent of Christ and the continuing authority of His Ten Commandment law with its reminder of the seventh-day Sabbath.   </li>   <li><em>Teaching </em>– Acknowledging that development of mind and character is essential to God’s redemptive plan, we promote the growth of a mature understanding of and relationship to God, His Word, and the created universe.</li><li><em>Healing </em>– Affirming the biblical emphasis on the well-being of the whole person, we make the preservation of health and the healing of the sick a priority and through our ministry to the poor and oppressed, cooperate with the Creator in His compassionate work of restoration.   Our Vision: In harmony with the great prophecies of the Scriptures, we see as the climax of God’s plan the restoration of all His creation to full harmony with His perfect will and righteousness.   </li> </ol>', '', 1, 1, 0, 2, '2008-10-07 00:17:04', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 00:17:04', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 5, '', '', 0, 5, 'robots=\nauthor='),
(5, 'The Seventh-day Adventist Logo', 'sda-logo', '', '<img src="images/sda-logo1.gif" border="0" alt="SDA Logo" title="The Logo of the Seventh-day Adventist Church" width="400" height="132" /><p>The choice of the Church''s logo reflects the core values that Seventh-day Adventists are committed to. The foundation is the Bible, the Word of God, shown open since its message must necessarily be read and put into practice. Central to that Biblical message is the Cross, and is also central in the logo. Above the Cross and the open Bible is the burning flame of the Holy Spirit, the messenger of Truth. </p> <p> It is our hope and prayer that though this logo is a very simple picture of the foundation of Adventist beliefs and values it may be a recognizable symbol of the Adventist message to the world. </p> <h3>Who May Use The Logo</h3> <p> The registered trademark may be used by the Seventh-day Adventist Church, its entities, institutions, and churches, as authorized by the General Conference of Seventh-day Adventists, its divisions, unions, and conferences.</p><p><img src="images/logowithglobe.gif" border="0" title="Description of SDA Logo" width="450" height="465" /> </p>', '', 1, 1, 0, 2, '2008-10-07 00:49:20', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 00:49:20', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 7, '', '', 0, 4, 'robots=\nauthor='),
(6, 'History of the SDA Church in India', 'history-sda-india', '', '<p> Though Stephen Haskell and Percy Magan crossed India on their mission survey around the world in 1890, it was not till 1893 that William Lenker and A. T. Stroup started selling Adventist literature in Madras. </p> <p> Shortly before their arrival Anna Gordon passed away. She had begun to observe the Sabbath in London and went to India as a self-supporting missionary. Lenker described her as a “faithful worker for God and a teacher of Adventist doctrines.” It is also recorded that before any Adventist work was opened in India, Dr. John Harvey Kellogg supported B.N. Mitter in his work. Mitter joined the regular Adventist work force when they arrived in 1895. </p> <p> The first regular Adventist worker to reach India was Georgia Burrus who arrived in Kolkata on Jan 23, 1895. Elder D. A. Robinson had intended to travel with her, but was delayed till Nov 8 of that year at which time he arrived with Martha May Taylor. Captain Masters and his wife who returned to India from New Zealand after becoming Adventists met Georgia Burrus on her arrival. </p> <p> Georgia Burrus worked in the zenanas of Baliaghatta and Dores Robinson opened the first Adventist schools (1896, 1897) for girls. An orphanage for boys opened in 1897 but moved to Karmatar, Jharkhand (1898) for vocational training. Dr O. G. Place and nurses Samantha Whiteis and Maggie Green opened the first treatment rooms in 1896. The Adventists moved their headquarters to Lucknow in 1909 and opened several Urdu schools (1910) and an English school at Mussoorie (1911). </p> <p> Meanwhile, in the south, a group of Tamil merchants through personal Bible study had begun to observe Saturday as the Sabbath. J. S. James worked among them from 1906. Suvisesha Muthu became an Adventist through reading literature and took to selling the same literature in and around Trivandrum, converting practically an entire community that today is renamed Adventpuram. H. G. Woodward worked there in 1918. </p> <p> A group of Telegus became Seventh-day Adventists in Rangoon and returned to Andhra. J.S. James visited them in 1915, and in 1918 T. R. Flaiz settled at Narsapur. Georgia Burrus and her husband L. J. Burgess retired in Meghalaya in the 1930s. W. G. Lowry pioneered the work among the Mizos around 1950. Dr S. G. Sturgess moved to Nepal in 1957. Following government approval a hospital financed by the Scheers opened on May 18, 1960 at Banepa. Today nursing and medical training is conducted there. </p> <p> Till 1909 the work in British India was operated as a detached Mission of the General Conference. The India Union Mission was organized in 1910 with J. L. Shaw as the first superintendent. It was joined to the Asiatic Division in 1915. </p> <p> The Southern Asia Division was organized under president J. E. Fulton in 1919 with 26 churches and 978 members. </p>', '', 1, 1, 0, 2, '2008-10-07 17:06:06', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 17:06:06', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 6, '', '', 0, 15, 'robots=\nauthor='),
(7, 'What Adventists Believe', 'what-sda-believe', '', '<p> As a Christian church, Seventh-day Adventists are a faith community rooted in the beliefs described by the Holy Scriptures. Adventists describe these beliefs in the following ways: </p> <h3> God''s greatest desire is for you to see a clear picture of His character. When you see Him clearly, you will find His love irresistible. </h3> <p> For many, "seeing God clearly" requires that they see God''s face. However, how He looks is not the issue. Seeing and understanding His character is what''s most important. The more clearly we understand Him, the more we will find His love irresistible. As we begin to experience His love, our own lives will begin to make more sense. </p> <p> God most clearly reveals His character in three great events. The first is His creation of man and woman--and His giving them the freedom of choice. He created humans with the ability to choose to love Him or to hate Him! The death of Jesus Christ, God''s only Son, on the cross as our substitute is the second great event. In that act He paid the penalty we deserve for our hateful choices toward God and His ways. Jesus'' death guarantees forgiveness for those choices and allows us to spend eternity with Him. The third event confirms the first two and fills every heart with hope: Christ''s tomb is empty! He is alive, living to fill us with His love! </p> <p> Jesus'' disciple John wrote that if everyone wrote all the stories they knew about Jesus, the whole world could not contain them. Our knowledge of God helps us understand His love, character, and grace. Experiencing that love begins a lifelong adventure in growth and service. This knowledge and experience powers our mission to tell the world about His love and His offer of salvation. </p> <h3> Scripture is a road map. The Bible is God''s voice, speaking His love personally to you today. </h3> <p> The Bible speaks the Creator''s directions to us, like a detailed road map that clearly shows the exit ramp directly into heaven. It is also much like an owner''s manual for a life ready to be lived on the cutting edge of liberty. </p> <p> Sometimes His voice speaks through stories, such as those of David and Goliath, Ruth and Boaz, Naaman''s little servant girl, Christ on the cross, and fisherman Peter learning how to tend sheep. Some of these stories teach us how to handle the troubles we face each day. Others fill us with hope and peace. Each of them is like a personal letter from God to you. </p> <p> Portions of Scripture are direct instructions and laws from God such as the Ten Commandments, recorded in Exodus 20. These tell us more about God and His expectations for us. When people asked Jesus to summarize these commands, He focused on the way God''s love affects the way we live. "Love the Lord your God with all your heart, mind, and soul," He said. "And love your neighbour as you love yourself." </p> <p> On other pages the Bible gives God''s practical advice and encouragement through parables, lists, promises, and warnings. Amazingly, though many different writers throughout thousands of years wrote the Bible, each page describes the same God in ways we can understand and apply in our lives today. This book is always His voice talking personally to anyone who is willing to read and hear. </p> <p> God loves us even when we choose to reject His love. In those times He allows us to walk away into the life of our own choices. Yet He is still there, always ready to redeem us from the results of our decisions. </p> <h3> Jesus is the one who never changes in a universe that always does. Jesus is Creator, Sustainer, Saviour, Friend, God''s Son, and God Himself! </h3> <p> Everything in this world is always changing, even our desires, interests, skills, and body shapes. But Jesus? He''s consistent. He''s always the same. Sure, He''s always surprising us and touching our lives in thousands of new and different ways, but His character is unchanging. He''s God''s Son, the Creator, our Saviour, and Friend. </p> <p> Jesus has promised to be all of that, and more, for each of us. We can trust His promises because He is God. When the words of Colossians say "in Him all things hold together" (1:17, NIV) that includes everything in our lives. He keeps us whole when the enemy is trying to make us fall apart. </p> <p> Seventh-day Adventists believe that Jesus is one of the three persons, called the Trinity, who make up our one God. The Bible describes Jesus, the Father, and the Holy Spirit as each being committed to our growth as Christians and to our salvation as their children. They made this salvation possible when Jesus came to Bethlehem as a human baby. He lived a life perfectly in accord with God''s will and then died innocently for all of our sins. He was placed in a borrowed tomb, but He came back to life three days later. Now he is in heaven interceding with the Father for us, preparing for our deliverance from sin and death. </p> <p> When everything may be falling apart, when you feel totally alone in the universe, Jesus is right there in the center of it all, offering personal peace and hope. Allow Him into your life. He immediately begins "remodelling" who you are and how you live. Jesus, in fact, is busily transforming His followers into accurate representatives of God''s character. </p> <p> Look to Jesus, and you''ll be looking into the understanding and loving face of God. </p> <h3> God''s vision for you is life as He lives it! God loves you, and wants to give you the highest quality of life imaginable. </h3> <p> No, not a second-rate existence somewhere on earth, but the highest quality of life imaginable, here and in eternity with Him! That''s what God wants us to have. The best! </p> <p> This is why He provides church families where we can belong. This is why He gives each of us special gifts and talents, so we can live life fully. Amazingly, this is why He''s concerned about what you''re doing, when you''re doing it, and how you relate to Him. God doesn''t want anything to get in the way of our friendship. He especially doesn''t want us to get involved in anything damaging or hurtful. He''s like a loving father or a good big brother. He''s someone who loves you so much that He''s always looking out for you. </p> <p> When God designed you, He included special talents and skills that will help you become a uniquely valuable individual. These may be your ability to teach, your love for others, or your leadership skills. Still, whatever special gifts you have received, God has also provided all of the energy and wisdom necessary for you to use them well. </p> <p> By the way, how God feels about death is part of the quality life He offers. For followers of Christ, death holds no fear. Remember, Jesus defeated death on Calvary and has given us freedom from death. Cemeteries, then, are filled with followers of God who are in the "peaceful pause before the resurrection." Yes, they are dead, but that death holds no power over their future. Jesus is coming to take them (and those of us who are still living) HOME! Death is almost like a wintery promise of spring. </p> <p> The Seventh-day Adventist faith in today and in the future comes from seeing this life "overflowing" with hope! </p> <p> Because love is the key aspect of His character, God is also deeply into gratitude. Before we even finish saying thank you, He''s already busy sending more blessings. </p> <h3> In the heart of God is a place you can experience as home. God loves you, and wants to spend time with you personally, one on one, as two close friends. </h3> <p> Because you and God are friends, you will spend time together as friends do. Each morning you''ll share a hello and a hug and discuss how you can face the day''s events together. Throughout the day you''ll talk with Him about how you feel. You''ll laugh with Him at funny things and ache with Him over sadness and hurts. It''s pleasant being God''s friend, able to snuggle comfortably into the safety of your relationship. You can always trust Him to treat you well, because He loves you. </p> <p> The seventh day (Saturday) is an extra-special part of the relationship. The Bible, from Genesis through Revelation, describes the seventh day as the one day God has set aside for focused fellowship with His people. God has named that day "Sabbath" and asked us to spend it with Him. "Remember the Sabbath day," He says, "to keep it holy." The Sabbath is a whole day to deepen our friendship with the Creator of the universe! A day when we''re together, Jesus with us and us with Jesus. </p> <p> There''s another great truth about friendship with God. It doesn''t end in a cemetery, for God is planning a homecoming better than anything we can dream. A homecoming filled with angels, trumpets, Jesus, and resurrections! He''s promised to bring His followers, those who have accepted the offer of His life-changing love, from this earth to His home, a place He calls heaven. A place where our friendship can go on growing forever, endlessly, joyfully! </p> <ul>   <li>     God keeps a family album-and your picture is in it. God loves you and has a plan for your life.    </li> </ul> <p> God''s love is about you. Personally. </p> <p> God made you and has a very special plan for your life. It''s a plan that will fill you with hope, love, peace, and activity. In fact, when Christ paid the penalty for sin on the cross, that gave Him the right to claim you as His own. As a result, you can experience His love and priceless salvation freely and fully without limit. </p> <p> By the way, pictures of everyone fill that album: Nepalese, Brazilians, Nigerians, Yupiks, Germans, people of every nation, culture, background, gender, hair colour, and foot size. In God''s eyes all are equally "children of the King"! </p> <p> Salvation? God cleans away all our sins and replaces them with His goodness. We don''t have to be "good" for Him to accept us. Nevertheless, we must accept His promise and allow Him to clean out everything the enemy has left in us. Then we begin to experience the transforming power of His love. It''s like a giant war: one side pulling us toward empty pleasure and destruction, and God urging us to accept His offer of peace and purpose. </p> <p> Remember, Jesus has already won the war. He is victorious! We celebrate His victory in our lives when we participate in the Lord''s Supper. This meal includes three symbols: </p> <ul>   <li>     Foot washing (which symbolizes our commitment to love others as Jesus loves us),   </li>   <li>     bread ("This bread is my flesh," Jesus said, "which I will give for the life of the world," John 6:51, NIV), and   </li>   <li>     wine or grape juice ("Whoever eats my flesh and drinks my blood has eternal life." John 6:54, NIV)   </li>  </ul> <p> To help us understand how God can transform us into His children, Jesus modelled the process of baptism for us. Baptism symbolized dying to self and coming alive in Jesus. Seventh-day Adventists practice full immersion baptism because by being fully buried beneath the water we symbolize that God''s grace fully fills us with His new life for the future. Through baptism we are truly born again in Jesus. </p> <p> Eternal life, peace, purpose, forgiveness, transforming grace, hope: Everything He promises is ours, because He''s offering it and He''s shown we can trust Him to do exactly as He promises. Accept His gifts, and you immediately become an active part of His family, and He joyfully becomes part of yours. </p>', '', 1, 1, 0, 2, '2008-10-07 17:14:12', 62, '', '2008-10-07 18:07:50', 62, 0, '0000-00-00 00:00:00', '2008-10-07 17:14:12', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 4, '', '', 0, 7, 'robots=\nauthor='),
(8, 'Brief Overview of Seventh-day Adventists', 'sda-info-brief', '', '<h3>Name</h3> <p> Seventh-day Adventists: the name highlights two beliefs that reflect two core Christian values important to the Church The second coming (or “advent”) of Jesus expresses the vital hope of the Church; the seventh-day Sabbath (Saturday) emphasizes the Biblical day of worship of the Creator and Savior of the world. </p>  <h3>Belief in Action</h3> <p> The most important truth Adventists want to share is belief in the trustworthy and gracious God of the Bible. Adventists believe in God as Creator, as Savior, but most of all as both Friend and Lord; the God who values most highly the freedom of His created beings, to whom He offers salvation in the present and eternal life in the soon-coming future. </p> <p> As a result, Adventists place great emphasis on different aspects of human freedom and responsibility, including: </p> <ul>   <li>religious liberty and human rights</li>   <li>humanitarian aid and development</li>   <li>better lifestyles</li>   <li>health and wholeness</li>   <li>education and personal growth</li>   <li>social issues and community involvement</li> </ul> <p> Adventists see their adherence to these values as a way of illustrating both faith in the God who cares intimately about every one of Earth’s inhabitants, and the church’s commitment to the betterment of fellow human beings. </p>  <h3>A World-wide People</h3> <p> The Adventist Church is active in 205 of the 230 countries recognized by the United Nations. High concentrations of Adventists are found in Central and South America, East and West Africa, the Philippines and many other areas. In composition, 39 percent of Adventists are African, 30 percent Hispanic, 14 percent East Asian and 11 percent Caucasian. </p>  <h3>A Growing People</h3> <p> Adventist Church membership is growing at the rate of almost one million every year, with new members joining the Church at the rate of one every 35 seconds. Globally the church is doubling every twelve years, with a current baptized membership of 11 million. </p>  <h3>People with a Global Mission</h3> <p> Adventists believe in sharing beliefs and values, and recognize the importance of telling others of the gospel message of Jesus Christ. The church’s “Global Mission” initiative attempts to communicate this message through seminars and outreach programs, the church’s medical mission and education system, and through pastors and members who dedicate their lives service to others. </p>  <h3>Aid to Humanity</h3> <p> Through organizations like the Adventist Development and Relief Agency International and other programs, the Adventist Church reaches out to provide practical help to those affected by disaster and requiring development assistance. This aid is provided without discrimination to all those in need, and includes food aid, medical supplies, equipment, and building materials, as well as educational programs and facilities, drug-awareness, social action, and agricultural development. </p>  <h3>Educating and individual development</h3> <p> The Adventist Church is committed to making education accessible in as many areas of the world as possible. Education, the church, believes, results in a better trained society and helps individuals reach their full potential. At the heart of the Adventist world-wide educational system is the conviction that every individual needs to have the opportunity to study and to grow. The Adventist education program now has more than one million students in over 5,500 schools, colleges, and universities-making it the largest Protestant education system in the world. </p>  <h3>Using Technology</h3> <p> Recognizing the benefits of modem technology, the Adventist Church has a wide network of satellite downlinks and regular satellite broadcasts; a highly-developed radio ministry broadcasting in more than 40 languages; and an extensive range of Web sites on the Internet. The church’s official Web site www.adventist.org receives over 500,000 unique visitors per year. </p>  <h3>Healthy Living</h3> <p> Not only concerned with spiritual health, Adventists promote a vegetarian lifestyle free from alcohol, smoking, and the use of illegal drugs. The world-renown “Stop Smoking” programs operated by the Church have allowed hundreds of thousands of people to quit the habit, while many others have been helped to a healthier lifestyle through seminars and nutrition programs. </p>  <h3>Medical Contributions</h3> <p> The Adventist Church has made many contributions to health and wholeness through its extensive medical ministry, operating 162 hospitals and sanitariums and more than 300 clinics worldwide. The Church’s Loma Linda University Medical Center is world-famous for its heart transplant program and the newly-developed but already highly-effective Proton Treatment Center which uses high-speed protons to attack a number of cancers with greater precision than traditional treatments. </p>  <h3>Love in Action</h3> <p> Adventists value the opportunity to share their faith through actions in the service of others, recognizing the Bible’s words: “Let us not love with words or tongue but with actions and in truth.” (1 John 3:18 NIV). </p>', '', 1, 1, 0, 2, '2008-10-07 18:17:41', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 18:17:41', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 13, 'robots=\nauthor='),
(9, 'Brief Overview of Adventist History', 'history-sda', '', '<p>Organized in 1863, the Seventh-day Adventist Church has its doctrinal roots in the “Advent Awakening” movement of the 1840s. Hundreds of thousands of Christians became convinced from their study of Bible prophecy that Christ would soon return. This re-awakening of a neglected Biblical belief occurred in many countries, with a major focus in North America. </p> <p> After the “great disappointment” of their hopes in 1844, these “advent believers” broke up into a number of different groups. One group, studying their Bibles for increased understanding, recognized the seventh-day Sabbath (Saturday) as the day of worship. This group, which included Ellen and James White and Joseph Bates, became the nucleus of the church congregations that chose the name “Seventh-day Adventist Church” and organized in Battle Creek, Michigan, with 125 churches and 3,500 members. </p> <p> Ellen White‘s ministry under God’s special guidance greatly influenced the development of the Adventist Church. Her counsels and messages to believers and church leaders shaped the form and progress of the church, while its beliefs have remained totally Bible-based. </p> <p> Other early Adventists of note include John Harvey Kellogg, inventor of the “cornflake” developed by his brother Will and pioneer of the Battle Creek Sanitarium; Joseph Bates, retired sea captain and first leader of an Adventist administration; Uriah Smith, prolific author and inventor, and editor of the church’s paper for almost 50 years. </p> <p> Adventist missionaries began work outside of North America in 1864, and ten years later J. N. Andrews was sent to Switzerland as the denomination’s first official missionary. In 1890, an Adventist minister began working in Russia, while in 1894 church operations commenced in Africa (Ghana and South Africa). Missionaries also arrived in South America in 1894, and in Japan in 1896. The church now operates in 205 countries worldwide. </p> <p> Growth from the early days has been dramatic. From the small group meeting in 1846 and the organization of the church with 3,500 believers, Seventh-day Adventists now number 11 million worldwide. </p>', '', 1, 1, 0, 2, '2008-10-07 18:26:25', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 18:26:25', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 12, 'robots=\nauthor='),
(10, 'Your Adventist Neighbour', 'adventist-neighbour', '', '<h3>What to expect from your Seventh-day Adventist neighbour, or, a few answers to frequently asked questions</h3>  <p> It''s 9:00 Saturday morning and your neighbours have just come out of their front door dressed as though they''re going to a symphony concert. But two of them are carrying Bibles! Chances are your neighbours are Seventh-day Adventists on their way to Sabbath morning worship services at their church. That means you''re in for a very special relationship, a friendship marked by kindness, openness, and honesty--one that could well enrich your life. </p> <p> You will find your Adventist friends committed to some very specific beliefs about God and about God''s relationships with people. They will be genuinely concerned about the needs of others and interested in bettering your community. If you observe them at their workplace, within their families, and at their church, they will be busily involved in many activities. </p> <p> Watch your neighbours closely, and you''ll probably notice (at least) the following: </p> <ul>   <li>Their love for God supersedes everything else in their lives</li>   <li>They worship on Saturday instead of Friday or Sunday</li>   <li>No beer cans or wine bottles dot their trash</li>   <li>They value their health</li>   <li>They appear upbeat and friendly</li>   <li>They work hard to make the community look great</li>   <li>They want to hear what makes you and your family happy</li> </ul> <p> You will soon discover that your neighbours genuinely like you and accept you as you are. They share their friendship across the back fence, in the marketplace, and at the bus stop. You''ll see smiles that come from a depth of peace--in the midst of chaos. That''s right, "chaos." Your Adventist neighbours are just like you. They experience the same stresses and disasters that strike everyone else in the neighbourhood. Yet you''ll notice a difference in how they respond to the challenges. They have a deep inner peace that allows them to look the enemy in the eye and smile. They are looking far beyond today''s troubles to the certainties of the future. Because they already know the outcome, they are comfortable with final victory! </p> <p> Peace, strong inner contentment, is a personal trait of committed Seventh-day Adventists. Many Allied pilots saw that peace in the lives of the Adventist Fiji Islanders who rescued them from the jungles during World War II. Residents of Florida, Iran, the Philippines, Somalia, and thousands of other places have seen that peace. It showed up in the lives of Adventist aid workers who helped them "dig out and start over" after earthquakes, tornadoes, fires, floods and other disasters. </p> <p> Your neighbourhood will see this peace in the lives of your Adventist friends, even when the well runs dry, a tree falls on the house, or the car is stolen from the parking lot. No, this peace is not a cavalier, "Oh, whatever!" attitude. It is the intense peace that comes from knowing God and that whatever happens here in this world is as "nothing" when compared to the joys of living forever in heaven with God. </p> <p> Sadness? Yes, that''s an Adventist emotion, but they believe God''s love comforts the sorrowing. </p> <p> Pain? Yes, Adventists experience pain. Their healthy lifestyle does allow them to live longer than others--as studies done on Adventists in the United States have shown. But Adventists still break limbs, contract cancer, fall off their bikes, and lose loved ones. Yet pain, even at its worst, is always accompanied by the healing love of God. </p> <p> Anger? Yes. Even anger shows up in the lives of Adventists. Remember, they''re normal people trying to live with God on a chaotic earth! But God is good enough to bring the calming power of His love into each angry situation. Even there the result is peace. </p> <p> Praise, an intense eagerness to thank God for all He is doing in our lives, is another visible trait of Seventh-day Adventists. If you stop by your neighbours'' home at breakfast time, you''ll probably find someone praying and reading a thought for the day from a book or the Bible while the others eat their meal. Evenings often include a time of thankfulness to God for a good day, Bible reading, and prayer. Many Friday and Wednesday nights your neighbours will participate in Bible study classes, public lectures on religion, or special activities for youth and children at their church. Saturday morning the whole family will join other church members for Sabbath School and a corporate worship service. Don''t be surprised if your neighbours invite you to join them at one or more of these activities. </p> <p> Sabbath school is like Sunday school. It is a one-hour time praising God through music, prayers, mission stories, and small group Bible study. During the time there are separate classes for children grouped according to their ages and for adults with varied interests and understanding of the Bible. Music and fellowship are central to each Sabbath school program. You will find Sabbath school to be a "good time" with each other and with God. </p> <p> The corporate worship service, or "church," is a more formal time of worship and praise. During this hour you will hear a practical, Bible-based sermon designed to help you see God more clearly and to provide you with strength to live as a Christian during the week. Church also includes worship music, public and personal prayers, and an opportunity to give tithe (10 percent of one''s income) and thank offerings to God. During the prayer time, worship leaders will give you an opportunity to share your personal needs or requests so these can be included in the congregational prayer. </p> <p> Seventh-day Adventist worship styles differ greatly. Some congregations conduct public worship very formally, often singing hymns and anthems accompanied by a pipe organ and piano. Worship in some other congregations is much more laid-back and features praise music led by guitars or even a small band. Still others reflect the cultural heritage of the congregation and may feature exuberant expressions of praise. Ask your neighbours to describe how their congregation worships so you''ll know what to expect when you accept their invitation to join them. Whatever the worship style, all Adventist congregations are worshiping the same eternal God who gives us cause for praise! </p> <p> Purpose, a deep commitment to accomplishing specific goals, is also a personal trait of Seventh-day Adventists. We are not here just to get up, go to work, and come home. We have accepted the challenge of Christ and so function as ambassadors of the Creator. Our purpose is to represent God so clearly that you will find His love irresistible! </p> <p> You''ll see that purpose when your Adventist friend talks about his son who is going abroad as a student missionary to help build a church. You''ll see it on the many evenings your neighbours go to church rather than stay home and watch TV. You''ll see it in their visible commitment to healthful living, to protecting life, to caring for the earth, and to building friendships with their neighbours. Adventists are a purposeful group of people, busy following a lifelong mission. That mission comes from the words of Jesus Christ Himself. "Therefore go and make disciples of all nations, baptizing them in the name of the Father and of the Son and of the Holy Spirit, and teaching them to obey everything I have commanded you" (Matthew 28:19, 20 NIV). </p> <p> Adventists believe that Jesus Christ is coming soon to take all of His followers home to an eternal heaven. Because Jesus has asked His followers to "go and teach," Adventists purposefully share the good news of Christ with everyone they can find--especially their neighbours! </p> <p> Peace, praise, and purpose. All of these result in a unique power for living, an internal energy that comes from having yielded to Christ. You will see this as a power that flows from God through your Adventist neighbour to you. That is our greatest hope as Adventists. </p> <p> We also hope that you will see in us the power, purpose, and peace that God offers to each human being. Even more, we hope you will find these to be so attractive that you will choose to accept Jesus Christ as your personal Saviour. Won''t you join us in this lifetime adventure called Christianity? </p>', '', 1, 1, 0, 2, '2008-10-07 18:39:11', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-07 18:39:11', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 1, '', '', 0, 6, 'robots=\nauthor=');
INSERT INTO `jos_content` (`id`, `title`, `alias`, `title_alias`, `introtext`, `fulltext`, `state`, `sectionid`, `mask`, `catid`, `created`, `created_by`, `created_by_alias`, `modified`, `modified_by`, `checked_out`, `checked_out_time`, `publish_up`, `publish_down`, `images`, `urls`, `attribs`, `version`, `parentid`, `ordering`, `metakey`, `metadesc`, `access`, `hits`, `metadata`) VALUES
(11, 'East - Central India Union', 'east-central-india-union', '', '<ul class="addressInformation">\r\n  <li>2 Chapel Road</li>\r\n  <li>Hyderabad 500 001</li>\r\n  <li>Andhra Pradesh</li>\r\n  <li><strong>Telephone</strong>: 91(040)232-018-32/232-000-79</li>\r\n  <li><strong>Fax</strong>:  (040)232-027-04</li>\r\n  <li><strong>E-mail</strong>:   \r\n    <ul class="emails">\r\n      <li>ciusda1@sify.com</li>\r\n    </ul>\r\n  </li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:01:52', 62, '', '2008-10-28 18:31:08', 62, 0, '0000-00-00 00:00:00', '2008-10-28 18:01:52', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 7, '', '', 0, 3, 'robots=\nauthor='),
(12, 'Northeast India Union', 'northeast-india-union', '', '<ul class="addressInformation">\r\n  <li>"Santana," Laitumkhrah</li>\r\n  <li>Shillong 793 003</li>\r\n  <li>Meghalaya</li>\r\n  <li><strong>Telephone</strong>:  91(0364)252-2471</li>\r\n  <li><strong>Fax</strong>:  91(0364)252-2471</li>\r\n  <li><strong>E-mail</strong>:  \r\n    <ul class="emails"><li>neiusda1@sancharnet.in</li></ul>\r\n  </li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:20:07', 62, '', '2008-10-28 18:31:38', 62, 0, '0000-00-00 00:00:00', '2008-10-28 18:20:07', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 6, '', '', 0, 2, 'robots=\nauthor='),
(13, 'Northern India Union', 'northern-india-union', '', '<ul class="addressInformation">\r\n  <li>11 Hailey Road</li>\r\n  <li>New Delhi 110 001</li>\r\n  <li><strong>Telephone</strong>:  91(011)233-249-59, 233-296-81</li>\r\n  <li><strong>Fax</strong>:  91(011)233-249-59</li>\r\n  <li><strong>E-mail</strong>:  <ul class="emails"><li>niusda@vsnl.com</li></ul></li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:25:07', 62, '', '2008-10-28 18:30:26', 62, 0, '0000-00-00 00:00:00', '2008-10-28 18:25:07', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 2, 0, 5, '', '', 0, 1, 'robots=\nauthor='),
(14, 'South - Central India Union', 'south-central-india-union', '', '<ul class="addressInformation">\r\n  <li>Spencer Road</li>\r\n  <li>Frazer Town</li>\r\n  <li>Bangalore 560 005</li>\r\n  <li>Karnataka</li>\r\n  <li><strong>Telephone</strong>:  91(080)255-671-27, 255-698-378</li>\r\n  <li><strong>Fax</strong>:  91(080)253-027-21</li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:33:16', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-28 18:33:16', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 4, '', '', 0, 1, 'robots=\nauthor='),
(15, 'Southeast India Union', 'southeast-india-union', '', '<ul class="addressInformation">\r\n  <li>197 GST Road, Vandalur</li>\r\n  <li>Chennai 600 048</li>\r\n  <li>Tamil Nadu</li>\r\n  <li><strong>Telephone</strong>:  91(044)223-995-95, 223-995-96</li>\r\n  <li><strong>Fax</strong>:  91(044)223-996-52</li>\r\n  <li><strong>E-mail</strong>:  <ul class="emails"><li>siu_sda@vsnl.net</li></ul></li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:36:36', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-28 18:36:36', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 3, '', '', 0, 1, 'robots=\nauthor='),
(16, 'Southwest India Union', 'southwest-india-union', '', '<ul class="addressInformation">\r\n  <li>B. No. 753, Evergreen Lane</li>\r\n  <li>Moospet Road</li>\r\n  <li>Thrissur 680 005</li>\r\n  <li>Kerala</li>\r\n  <li><strong>Telephone</strong>:  91(0487)244-0341, 244-0343</li>\r\n  <li><strong>Fax</strong>:  91(0487)-2440-343</li>\r\n  <li><strong>E-mail</strong>:  \r\n    <ul class="emails"><li>keusda@sancharnet.in</li></ul>\r\n  </li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 18:40:51', 62, '', '0000-00-00 00:00:00', 0, 0, '0000-00-00 00:00:00', '2008-10-28 18:40:51', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 1, 0, 2, '', '', 0, 1, 'robots=\nauthor='),
(17, 'Western India Union', 'western-india-union', '', '<ul class="addressInformation">\r\n  <li>Post Box 1413, Market Yard</li>\r\n  <li>Pune 411 037</li>\r\n  <li>Maharashtra</li>\r\n  <li><strong>Telephone</strong>:  91(020)242-718-96, 242-718-9</li>\r\n  <li><strong>Fax</strong>:  91(020)242-730-20</li>\r\n</ul>', '', 1, 2, 0, 43, '2008-10-28 20:38:15', 62, '', '2008-10-28 20:52:51', 62, 0, '0000-00-00 00:00:00', '2008-10-28 20:38:15', '0000-00-00 00:00:00', '', '', 'show_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_vote=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nlanguage=\nkeyref=\nreadmore=', 3, 0, 1, '', '', 0, 4, 'robots=\nauthor=');

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_frontpage`
--

DROP TABLE IF EXISTS `jos_content_frontpage`;
CREATE TABLE IF NOT EXISTS `jos_content_frontpage` (
  `content_id` int(11) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_frontpage`
--

INSERT INTO `jos_content_frontpage` (`content_id`, `ordering`) VALUES
(1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_content_rating`
--

DROP TABLE IF EXISTS `jos_content_rating`;
CREATE TABLE IF NOT EXISTS `jos_content_rating` (
  `content_id` int(11) NOT NULL default '0',
  `rating_sum` int(11) unsigned NOT NULL default '0',
  `rating_count` int(11) unsigned NOT NULL default '0',
  `lastip` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_content_rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro`
--

DROP TABLE IF EXISTS `jos_core_acl_aro`;
CREATE TABLE IF NOT EXISTS `jos_core_acl_aro` (
  `id` int(11) NOT NULL auto_increment,
  `section_value` varchar(240) NOT NULL default '0',
  `value` varchar(240) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `jos_section_value_value_aro` (`section_value`(100),`value`(100)),
  KEY `jos_gacl_hidden_aro` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro`
--

INSERT INTO `jos_core_acl_aro` (`id`, `section_value`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', '62', 0, 'Administrator', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_groups`
--

DROP TABLE IF EXISTS `jos_core_acl_aro_groups`;
CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_groups` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11) NOT NULL default '0',
  `name` varchar(255) NOT NULL default '',
  `lft` int(11) NOT NULL default '0',
  `rgt` int(11) NOT NULL default '0',
  `value` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `jos_gacl_parent_id_aro_groups` (`parent_id`),
  KEY `jos_gacl_lft_rgt_aro_groups` (`lft`,`rgt`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- Dumping data for table `jos_core_acl_aro_groups`
--

INSERT INTO `jos_core_acl_aro_groups` (`id`, `parent_id`, `name`, `lft`, `rgt`, `value`) VALUES
(17, 0, 'ROOT', 1, 22, 'ROOT'),
(28, 17, 'USERS', 2, 21, 'USERS'),
(29, 28, 'Public Frontend', 3, 12, 'Public Frontend'),
(18, 29, 'Registered', 4, 11, 'Registered'),
(19, 18, 'Author', 5, 10, 'Author'),
(20, 19, 'Editor', 6, 9, 'Editor'),
(21, 20, 'Publisher', 7, 8, 'Publisher'),
(30, 28, 'Public Backend', 13, 20, 'Public Backend'),
(23, 30, 'Manager', 14, 19, 'Manager'),
(24, 23, 'Administrator', 15, 18, 'Administrator'),
(25, 24, 'Super Administrator', 16, 17, 'Super Administrator');

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_map`
--

DROP TABLE IF EXISTS `jos_core_acl_aro_map`;
CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_map` (
  `acl_id` int(11) NOT NULL default '0',
  `section_value` varchar(230) NOT NULL default '0',
  `value` varchar(100) NOT NULL default '',
  PRIMARY KEY  (`acl_id`,`section_value`,`value`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_aro_map`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_aro_sections`
--

DROP TABLE IF EXISTS `jos_core_acl_aro_sections`;
CREATE TABLE IF NOT EXISTS `jos_core_acl_aro_sections` (
  `id` int(11) NOT NULL auto_increment,
  `value` varchar(230) NOT NULL default '',
  `order_value` int(11) NOT NULL default '0',
  `name` varchar(230) NOT NULL default '',
  `hidden` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `jos_gacl_value_aro_sections` (`value`),
  KEY `jos_gacl_hidden_aro_sections` (`hidden`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `jos_core_acl_aro_sections`
--

INSERT INTO `jos_core_acl_aro_sections` (`id`, `value`, `order_value`, `name`, `hidden`) VALUES
(10, 'users', 1, 'Users', 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_acl_groups_aro_map`
--

DROP TABLE IF EXISTS `jos_core_acl_groups_aro_map`;
CREATE TABLE IF NOT EXISTS `jos_core_acl_groups_aro_map` (
  `group_id` int(11) NOT NULL default '0',
  `section_value` varchar(240) NOT NULL default '',
  `aro_id` int(11) NOT NULL default '0',
  UNIQUE KEY `group_id_aro_id_groups_aro_map` (`group_id`,`section_value`,`aro_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_acl_groups_aro_map`
--

INSERT INTO `jos_core_acl_groups_aro_map` (`group_id`, `section_value`, `aro_id`) VALUES
(25, '', 10);

-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_items`
--

DROP TABLE IF EXISTS `jos_core_log_items`;
CREATE TABLE IF NOT EXISTS `jos_core_log_items` (
  `time_stamp` date NOT NULL default '0000-00-00',
  `item_table` varchar(50) NOT NULL default '',
  `item_id` int(11) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_items`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_core_log_searches`
--

DROP TABLE IF EXISTS `jos_core_log_searches`;
CREATE TABLE IF NOT EXISTS `jos_core_log_searches` (
  `search_term` varchar(128) NOT NULL default '',
  `hits` int(11) unsigned NOT NULL default '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_core_log_searches`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_groups`
--

DROP TABLE IF EXISTS `jos_groups`;
CREATE TABLE IF NOT EXISTS `jos_groups` (
  `id` tinyint(3) unsigned NOT NULL default '0',
  `name` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_groups`
--

INSERT INTO `jos_groups` (`id`, `name`) VALUES
(0, 'Public'),
(1, 'Registered'),
(2, 'Special');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jce_extensions`
--

DROP TABLE IF EXISTS `jos_jce_extensions`;
CREATE TABLE IF NOT EXISTS `jos_jce_extensions` (
  `id` int(11) NOT NULL auto_increment,
  `pid` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `extension` varchar(255) NOT NULL default '',
  `folder` varchar(255) NOT NULL default '',
  `published` tinyint(3) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_jce_extensions`
--

INSERT INTO `jos_jce_extensions` (`id`, `pid`, `name`, `extension`, `folder`, `published`) VALUES
(1, 15, 'Joomla Links for Advanced Link', 'joomlalinks', 'links', 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_jce_groups`
--

DROP TABLE IF EXISTS `jos_jce_groups`;
CREATE TABLE IF NOT EXISTS `jos_jce_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  `users` text NOT NULL,
  `types` varchar(255) NOT NULL default '',
  `components` text NOT NULL,
  `rows` text NOT NULL,
  `plugins` varchar(255) NOT NULL default '',
  `published` tinyint(3) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `checked_out` tinyint(3) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_jce_groups`
--

INSERT INTO `jos_jce_groups` (`id`, `name`, `description`, `users`, `types`, `components`, `rows`, `plugins`, `published`, `ordering`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Default', 'Default group for all users with edit access', '', '19,20,21,23,24,25', '', '28,27,32,33,19,20,21,29,45,44,43,46,26,49,36,37,30,31,39,40;56,47,38,5,9,48,42,24,25,22,18,2;7,17,13,10,3;23,15,14,59,16,4,6,8,12,54,34,41,11', '1,52,53,55,57,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,28,54,59', 1, 1, 0, '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_jce_plugins`
--

DROP TABLE IF EXISTS `jos_jce_plugins`;
CREATE TABLE IF NOT EXISTS `jos_jce_plugins` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) NOT NULL default '',
  `name` varchar(100) NOT NULL default '',
  `type` varchar(100) NOT NULL default 'plugin',
  `icon` varchar(255) NOT NULL default '',
  `layout` varchar(255) NOT NULL default '',
  `row` int(11) NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `published` tinyint(3) NOT NULL default '0',
  `editable` tinyint(3) NOT NULL default '0',
  `elements` varchar(255) NOT NULL default '',
  `params` text NOT NULL,
  `iscore` tinyint(3) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `plugin` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `jos_jce_plugins`
--

INSERT INTO `jos_jce_plugins` (`id`, `title`, `name`, `type`, `icon`, `layout`, `row`, `ordering`, `published`, `editable`, `elements`, `params`, `iscore`, `checked_out`, `checked_out_time`) VALUES
(1, 'Context Menu', 'contextmenu', 'plugin', '', '', 0, 19, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(2, 'Directionality', 'directionality', 'plugin', 'ltr,rtl', 'directionality', 3, 26, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(3, 'Emotions', 'emotions', 'plugin', 'emotions', 'emotions', 3, 24, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(4, 'Fullscreen', 'fullscreen', 'plugin', 'fullscreen', 'fullscreen', 3, 27, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(5, 'Paste', 'paste', 'plugin', 'pasteword,pastetext', 'paste', 2, 15, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(6, 'Preview', 'preview', 'plugin', 'preview', 'preview', 3, 29, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(7, 'Tables', 'table', 'plugin', 'tablecontrols', 'buttons', 3, 11, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(8, 'Print', 'print', 'plugin', 'print', 'print', 3, 25, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(9, 'Search Replace', 'searchreplace', 'plugin', 'search,replace', 'searchreplace', 2, 18, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(10, 'Styles', 'style', 'plugin', 'styleprops', 'style', 4, 16, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(11, 'Non-Breaking', 'nonbreaking', 'plugin', 'nonbreaking', 'nonbreaking', 4, 21, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(12, 'Visual Characters', 'visualchars', 'plugin', 'visualchars', 'visualchars', 4, 20, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(13, 'XHTML Xtras', 'xhtmlxtras', 'plugin', 'cite,abbr,acronym,del,ins,attribs', 'xhtmlxtras', 4, 17, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(14, 'Image Manager', 'imgmanager', 'plugin', 'imgmanager', 'imgmanager', 4, 30, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(15, 'Advanced Link', 'advlink', 'plugin', 'advlink', 'advlink', 4, 31, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(16, 'Spell Checker', 'spellchecker', 'plugin', 'spellchecker', 'spellchecker', 4, 22, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(17, 'Layers', 'layer', 'plugin', 'insertlayer,moveforward,movebackward,absolute', 'layer', 4, 10, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(18, 'Font ForeColour', 'forecolor', 'command', 'forecolor', 'forecolor', 2, 17, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(19, 'Bold', 'bold', 'command', 'bold', 'bold', 1, 2, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(20, 'Italic', 'italic', 'command', 'italic', 'italic', 1, 3, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(21, 'Underline', 'underline', 'command', 'underline', 'underline', 1, 4, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(22, 'Font BackColour', 'backcolor', 'command', 'backcolor', 'backcolor', 2, 18, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(23, 'Unlink', 'unlink', 'command', 'unlink', 'unlink', 2, 11, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(24, 'Font Select', 'fontselect', 'command', 'fontselect', 'fontselect', 1, 12, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(25, 'Font Size Select', 'fontsizeselect', 'command', 'fontsizeselect', 'fontsizeselect', 1, 13, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(26, 'Style Select', 'styleselect', 'command', 'styleselect', 'styleselect', 1, 10, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(27, 'New Document', 'newdocument', 'command', 'newdocument', 'newdocument', 1, 1, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(28, 'Help', 'help', 'plugin', 'help', 'help', 1, 6, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(29, 'StrikeThrough', 'strikethrough', 'command', 'strikethrough', 'strikethrough', 1, 5, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(30, 'Indent', 'indent', 'command', 'indent', 'indent', 2, 7, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(31, 'Outdent', 'outdent', 'command', 'outdent', 'outdent', 2, 6, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(32, 'Undo', 'undo', 'command', 'undo', 'undo', 2, 8, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(33, 'Redo', 'redo', 'command', 'redo', 'redo', 2, 9, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(34, 'Horizontal Rule', 'hr', 'command', 'hr', 'hr', 3, 2, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(35, 'HTML', 'html', 'command', 'code', 'code', 2, 16, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(36, 'Numbered List', 'numlist', 'command', 'numlist', 'numlist', 2, 5, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(37, 'Bullet List', 'bullist', 'command', 'bullist', 'bullist', 2, 4, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(38, 'Clipboard Actions', 'clipboard', 'command', 'cut,copy,paste', 'clipboard', 2, 1, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(39, 'Subscript', 'sub', 'command', 'sub', 'sub', 3, 5, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(40, 'Superscript', 'sup', 'command', 'sup', 'sup', 3, 6, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(41, 'Visual Aid', 'visualaid', 'command', 'visualaid', 'visualaid', 3, 4, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(42, 'Character Map', 'charmap', 'command', 'charmap', 'charmap', 3, 7, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(43, 'Justify Full', 'full', 'command', 'justifyfull', 'justifyfull', 1, 8, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(44, 'Justify Center', 'center', 'command', 'justifycenter', 'justifycenter', 1, 7, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(45, 'Justify Left', 'left', 'command', 'justifyleft', 'justifyleft', 1, 6, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(46, 'Justify Right', 'right', 'command', 'justifyright', 'justifyright', 1, 9, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(47, 'Remove Format', 'removeformat', 'command', 'removeformat', 'removeformat', 3, 3, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(48, 'Anchor', 'anchor', 'command', 'anchor', 'anchor', 2, 12, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(49, 'Format Select', 'formatselect', 'command', 'formatselect', 'formatselect', 1, 11, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(50, 'Image', 'image', 'command', 'image', 'image', 2, 13, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(51, 'Link', 'link', 'command', 'link', 'link', 2, 10, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(52, 'File Browser', 'browser', 'plugin', '', '', 0, 28, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(53, 'Inline Popups', 'inlinepopups', 'plugin', '', '', 0, 12, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(54, 'Read More', 'readmore', 'plugin', 'readmore', 'readmore', 4, 23, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(55, 'Media Support', 'media', 'plugin', '', '', 0, 9, 1, 1, '', '', 1, 0, '0000-00-00 00:00:00'),
(56, 'Code Cleanup', 'cleanup', 'command', 'cleanup', 'cleanup', 2, 14, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(57, 'Safari Browser Support', 'safari', 'plugin', '', '', 0, 13, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00'),
(59, 'Advanced Code Editor', 'advcode', 'plugin', 'advcode', 'advcode', 4, 8, 1, 0, '', '', 1, 0, '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu`
--

DROP TABLE IF EXISTS `jos_menu`;
CREATE TABLE IF NOT EXISTS `jos_menu` (
  `id` int(11) NOT NULL auto_increment,
  `menutype` varchar(75) default NULL,
  `name` varchar(255) default NULL,
  `alias` varchar(255) NOT NULL default '',
  `link` text,
  `type` varchar(50) NOT NULL default '',
  `published` tinyint(1) NOT NULL default '0',
  `parent` int(11) unsigned NOT NULL default '0',
  `componentid` int(11) unsigned NOT NULL default '0',
  `sublevel` int(11) default '0',
  `ordering` int(11) default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `pollid` int(11) NOT NULL default '0',
  `browserNav` tinyint(4) default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `utaccess` tinyint(3) unsigned NOT NULL default '0',
  `params` text NOT NULL,
  `lft` int(11) unsigned NOT NULL default '0',
  `rgt` int(11) unsigned NOT NULL default '0',
  `home` int(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `componentid` (`componentid`,`menutype`,`published`,`access`),
  KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=60 ;

--
-- Dumping data for table `jos_menu`
--

INSERT INTO `jos_menu` (`id`, `menutype`, `name`, `alias`, `link`, `type`, `published`, `parent`, `componentid`, `sublevel`, `ordering`, `checked_out`, `checked_out_time`, `pollid`, `browserNav`, `access`, `utaccess`, `params`, `lft`, `rgt`, `home`) VALUES
(1, 'mainmenu', 'Home', 'home', 'index.php?option=com_content&view=frontpage', 'component', 1, 0, 20, 0, 45, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, 'num_leading_articles=1\nnum_intro_articles=4\nnum_columns=2\nnum_links=4\norderby_pri=\norderby_sec=front\nmulti_column_order=1\nshow_pagination=2\nshow_pagination_results=1\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=Southern Asia Division of SDA\nshow_page_title=0\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 1),
(2, 'generalinfo', 'Contact Us', 'contact-us', 'index.php?option=com_content&view=article&id=2', 'component', 1, 0, 20, 0, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(3, 'generalinfo', 'About Us', 'about-us', 'index.php?option=com_content&view=article&id=3', 'component', -2, 0, 20, 0, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(4, 'generalinfo', 'About Adventists', 'about-sda', 'index.php?option=com_content&view=article&id=8', 'component', 1, 0, 20, 0, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(9, 'generalinfo', 'Adventist History', 'history-sda', 'index.php?option=com_content&view=article&id=9', 'component', 1, 4, 20, 1, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(5, 'generalinfo', 'What Adventists Believe', 'what-sda-believe', 'index.php?option=com_content&view=article&id=7', 'component', 1, 4, 20, 1, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(6, 'generalinfo', 'Mission Statement', 'mission', 'index.php?option=com_content&view=article&id=4', 'component', 1, 4, 20, 1, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(7, 'generalinfo', 'History in India', 'history-sda-india', 'index.php?option=com_content&view=article&id=6', 'component', 1, 9, 20, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(8, 'generalinfo', 'The Adventist Logo', 'sda-logo', 'index.php?option=com_content&view=article&id=5', 'component', 1, 4, 20, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(10, 'generalinfo', 'Adventists as People', 'adventist-neighbour', 'index.php?option=com_content&view=article&id=10', 'component', 1, 4, 20, 1, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'show_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(11, 'mainmenu', 'Gallery', 'image-gallery', 'index.php?option=com_expose', 'component', -2, 0, 34, 0, 43, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=Southern Asia Division Picture Tour\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(12, 'mainmenu', 'Southern Asia Division Tour', 'Southern-Asia-Division-Tour', 'index.php?option=com_morfeoshow&amp;task=view&amp;gallery=1', 'component', -2, 0, 39, 0, 44, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, '', 0, 0, 0),
(13, 'mainmenu', 'Photo Gallery', 'photo-gallery', 'index.php?option=com_morfeoshow', 'component', -2, 0, 39, 0, 42, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(14, 'mainmenu', 'Photo Gallery', 'Photo-Gallery', 'index.php?option=com_morfeoshow&amp;task=view&amp;gallery=2', 'component', 1, 0, 39, 0, 46, 0, '0000-00-00 00:00:00', 0, 0, 0, 3, '', 0, 0, 0),
(15, 'mainmenu', 'The Layout', 'the-layout', 'index.php?option=com_qcontacts&view=category&catid=3', 'component', -2, 0, 43, 0, 40, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'image=-1\nimage_align=right\nshow_headings=1\nshow_col_name=1\nord_col_name=0\nwidth_col_name=\nshow_col_position=1\nord_col_position=1\nwidth_col_position=\nshow_col_email=0\nord_col_email=2\nwidth_col_email=\nshow_col_telephone=1\nord_col_telephone=3\nwidth_col_telephone=\nshow_col_mobile=0\nord_col_mobile=4\nwidth_col_mobile=\nshow_col_fax=0\nord_col_fax=5\nwidth_col_fax=\nshow_col_street=0\nord_col_street=6\nwidth_col_street=\nshow_col_suburb=0\nord_col_suburb=7\nwidth_col_suburb=\nshow_col_state=0\nord_col_state=8\nwidth_col_state=\nshow_col_postcode=0\nord_col_postcode=9\nwidth_col_postcode=\nshow_col_country=0\nord_col_country=10\nwidth_col_country=\ncontacts_per_page=\nshow_limit=0\nshow_feed_link=1\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(16, 'mainmenu', 'custom!', 'custom', 'index.php?option=com_qcontacts&view=categories', 'component', -2, 0, 43, 0, 41, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'page_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(17, 'mainmenu', 'Communication', 'communication', 'index.php?option=com_contact&view=category&catid=4', 'component', -2, 0, 7, 2, 26, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(18, 'mainmenu', 'Mail', 'mail', 'index.php?option=com_contact&view=category&catid=6', 'component', -2, 0, 7, 0, 39, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(19, 'mainmenu', 'Departments', 'departments', 'index.php?option=com_contact&view=categories&contact_section=1', 'component', 1, 20, 7, 1, 1, 62, '2008-10-29 21:32:05', 0, 0, 0, 0, 'contact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Departments\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(20, 'mainmenu', 'Directory', 'directory', 'index.php?option=com_contact&view=category&catid=0&contact_section=1', 'component', 1, 0, 7, 0, 47, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Directory\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(21, 'mainmenu', 'Education', 'education', 'index.php?option=com_contact&view=category&catid=5', 'component', -2, 0, 7, 2, 27, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Department of Education\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(22, 'mainmenu', 'Administrators', 'administrators', 'index.php?option=com_contact&view=category&catid=7', 'component', -2, 0, 7, 2, 28, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Administrators\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(58, 'mainmenu', 'Unions', 'unions', 'index.php?option=com_content&view=category&id=43', 'component', -2, 0, 20, 1, 0, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=10\nshow_headings=0\nshow_date=0\ndate_format=\nfilter=0\nfilter_type=title\norderby_sec=\nshow_pagination=1\nshow_pagination_limit=0\nshow_feed_link=1\nshow_noauth=\nshow_title=\nlink_titles=\nshow_intro=\nshow_section=\nlink_section=\nshow_category=\nlink_category=\nshow_author=\nshow_create_date=\nshow_modify_date=\nshow_item_navigation=\nshow_readmore=\nshow_vote=\nshow_icons=\nshow_pdf_icon=\nshow_print_icon=\nshow_email_icon=\nshow_hits=\nfeed_summary=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(23, 'mainmenu', 'ACI', 'aci', 'index.php?option=com_contact&view=category&catid=15', 'component', -2, 0, 7, 2, 29, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Adventist Child India\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(24, 'mainmenu', 'Adventist Media', 'adventist-media', 'index.php?option=com_contact&view=category&catid=39', 'component', -2, 0, 7, 2, 30, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Adventist Media Centre\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(25, 'mainmenu', 'ARM', 'arm', 'index.php?option=com_contact&view=category&catid=37', 'component', -2, 0, 7, 2, 31, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Adventist Risk Management\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(26, 'mainmenu', 'AVS', 'avs', 'index.php?option=com_contact&view=category&catid=38', 'component', -2, 0, 7, 2, 32, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Adventist Volunteer Service\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(27, 'mainmenu', 'Auditing', 'auditing', 'index.php?option=com_contact&view=category&catid=31', 'component', -2, 0, 7, 2, 37, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Auditing Service\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(28, 'mainmenu', 'Building', 'building', 'index.php?option=com_contact&view=category&catid=36', 'component', -2, 0, 7, 2, 36, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Building Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(29, 'mainmenu', 'Chaplaincy', 'chaplaincy', 'index.php?option=com_contact&view=category&catid=12', 'component', -2, 0, 7, 2, 35, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Chaplaincy\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(30, 'mainmenu', 'Children''s Ministries', 'childrens-ministries', 'index.php?option=com_contact&view=category&catid=10', 'component', -2, 0, 7, 2, 34, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Children''s Ministries Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(31, 'mainmenu', 'Church Nurturing', 'church-nurturing', 'index.php?option=com_contact&view=category&catid=11', 'component', -2, 0, 7, 2, 33, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Church Nurturing Ministries\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(32, 'mainmenu', 'Legal Affairs', 'legal-affairs', 'index.php?option=com_contact&view=category&catid=21', 'component', -2, 0, 7, 2, 24, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Department of Legal Affairs\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(33, 'mainmenu', 'FDIC', 'fdic', 'index.php?option=com_contact&view=category&catid=14', 'component', -2, 0, 7, 2, 23, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Faith Development in Context\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(34, 'mainmenu', 'Family', 'family', 'index.php?option=com_contact&view=category&catid=16', 'component', -2, 0, 7, 2, 10, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Family Ministries\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(35, 'mainmenu', 'Global Mission', 'global-mission', 'index.php?option=com_contact&view=category&catid=18', 'component', -2, 0, 7, 2, 9, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Global Missions Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(36, 'mainmenu', 'Health & Temperance', 'health-a-temperance', 'index.php?option=com_contact&view=category&catid=19', 'component', -2, 0, 7, 2, 8, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Health and Temperance Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(37, 'mainmenu', 'Hinduism Study', 'hinduism-study', 'index.php?option=com_contact&view=category&catid=33', 'component', -2, 0, 7, 2, 7, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Hinduism Study Centre\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(38, 'mainmenu', 'Intra Church Pub.', 'intra-church-pub', 'index.php?option=com_contact&view=category&catid=41', 'component', -2, 0, 7, 2, 6, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Intra Church Publications\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(39, 'mainmenu', 'Ministerial', 'ministerial', 'index.php?option=com_contact&view=category&catid=22', 'component', -2, 0, 7, 2, 5, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Ministerial Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(40, 'mainmenu', 'Blind Ministries', 'blind-ministries', 'index.php?option=com_contact&view=category&catid=27', 'component', -2, 0, 7, 2, 4, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Ministry to the Blind\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(41, 'mainmenu', 'Oriental Watchman', 'oriental-watchman', 'index.php?option=com_contact&view=category&catid=40', 'component', -2, 0, 7, 2, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Oriental Watchman Publishing House\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(42, 'mainmenu', 'PARL', 'parl', 'index.php?option=com_contact&view=category&catid=13', 'component', -2, 0, 7, 2, 2, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=PARL\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(43, 'mainmenu', 'Personal Ministries', 'personal-ministries', 'index.php?option=com_contact&view=category&catid=26', 'component', -2, 0, 7, 2, 11, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Personal Ministries Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(44, 'mainmenu', 'Publishing', 'publishing', 'index.php?option=com_contact&view=category&catid=23', 'component', -2, 0, 7, 2, 12, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Publishing Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(45, 'mainmenu', 'Retirement', 'retirement', 'index.php?option=com_contact&view=category&catid=24', 'component', -2, 0, 7, 2, 13, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Retirement Plan Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(46, 'mainmenu', 'Sabbath School', 'sabbath-school', 'index.php?option=com_contact&view=category&catid=25', 'component', -2, 0, 7, 2, 22, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Sabbath School Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(47, 'mainmenu', 'Satellite Evangelism', 'satellite-evangelism', 'index.php?option=com_contact&view=category&catid=35', 'component', -2, 0, 7, 2, 21, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Satellite Evangelism\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(48, 'mainmenu', 'Secretariat', 'secretariat', 'index.php?option=com_contact&view=category&catid=8', 'component', -2, 0, 7, 0, 38, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Secretariat Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(49, 'mainmenu', 'Secretariat', 'secretariat', 'index.php?option=com_contact&view=category&catid=8', 'component', -2, 0, 7, 2, 20, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Secretariat Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(50, 'mainmenu', 'Tidings', 'tidings', 'index.php?option=com_contact&view=category&catid=32', 'component', -2, 0, 7, 2, 19, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Southern Asia Tidings\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(51, 'mainmenu', 'Special Ministries', 'special-ministries', 'index.php?option=com_contact&view=category&catid=28', 'component', -2, 0, 7, 2, 25, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Special Ministries Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(52, 'mainmenu', 'Spirit of Prophecy', 'spirit-of-prophecy', 'index.php?option=com_contact&view=category&catid=34', 'component', -2, 0, 7, 2, 18, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Spirit of Prophecy Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(53, 'mainmenu', 'Stewardship', 'stewardship', 'index.php?option=com_contact&view=category&catid=20', 'component', -2, 0, 7, 2, 17, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Stewardship Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(54, 'mainmenu', 'Treasury', 'treasury', 'index.php?option=com_contact&view=category&catid=9', 'component', -2, 0, 7, 2, 16, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Treasury Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(55, 'mainmenu', 'TRUST Services', 'trust-services', 'index.php?option=com_contact&view=category&catid=29', 'component', -2, 0, 7, 2, 15, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=TRUST Services Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(56, 'mainmenu', 'Women''s Ministries', 'womens-ministries', 'index.php?option=com_contact&view=category&catid=30', 'component', -2, 0, 7, 2, 14, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Women''s Ministries Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(57, 'mainmenu', 'Youth', 'youth', 'index.php?option=com_contact&view=category&catid=17', 'component', -2, 0, 7, 2, 1, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'display_num=20\nimage=-1\nimage_align=right\nshow_limit=0\nshow_feed_link=1\ncontact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=Youth Ministries Department\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0),
(59, 'mainmenu', 'Unions', 'unions', 'index.php?option=com_contact&view=categories&contact_section=2', 'component', 1, 20, 7, 1, 3, 0, '0000-00-00 00:00:00', 0, 0, 0, 0, 'contact_icons=\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_misc=\nshow_headings=\nshow_position=\nshow_email=\nshow_telephone=\nshow_mobile=\nshow_fax=\nallow_vcard=\nbanned_email=\nbanned_subject=\nbanned_text=\nvalidate_session=\ncustom_reply=\npage_title=\nshow_page_title=1\npageclass_sfx=\nmenu_image=-1\nsecure=0\n\n', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_menu_types`
--

DROP TABLE IF EXISTS `jos_menu_types`;
CREATE TABLE IF NOT EXISTS `jos_menu_types` (
  `id` int(10) unsigned NOT NULL auto_increment,
  `menutype` varchar(75) NOT NULL default '',
  `title` varchar(255) NOT NULL default '',
  `description` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `menutype` (`menutype`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_menu_types`
--

INSERT INTO `jos_menu_types` (`id`, `menutype`, `title`, `description`) VALUES
(1, 'mainmenu', 'Main Menu', 'The main menu for the site'),
(2, 'generalinfo', 'General Information', 'Information about the Southern Asia Division and SDA');

-- --------------------------------------------------------

--
-- Table structure for table `jos_messages`
--

DROP TABLE IF EXISTS `jos_messages`;
CREATE TABLE IF NOT EXISTS `jos_messages` (
  `message_id` int(10) unsigned NOT NULL auto_increment,
  `user_id_from` int(10) unsigned NOT NULL default '0',
  `user_id_to` int(10) unsigned NOT NULL default '0',
  `folder_id` int(10) unsigned NOT NULL default '0',
  `date_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `state` int(11) NOT NULL default '0',
  `priority` int(1) unsigned NOT NULL default '0',
  `subject` text NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY  (`message_id`),
  KEY `useridto_state` (`user_id_to`,`state`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_messages_cfg`
--

DROP TABLE IF EXISTS `jos_messages_cfg`;
CREATE TABLE IF NOT EXISTS `jos_messages_cfg` (
  `user_id` int(10) unsigned NOT NULL default '0',
  `cfg_name` varchar(100) NOT NULL default '',
  `cfg_value` varchar(255) NOT NULL default '',
  UNIQUE KEY `idx_user_var_name` (`user_id`,`cfg_name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_messages_cfg`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_migration_backlinks`
--

DROP TABLE IF EXISTS `jos_migration_backlinks`;
CREATE TABLE IF NOT EXISTS `jos_migration_backlinks` (
  `itemid` int(11) NOT NULL default '0',
  `name` varchar(100) NOT NULL default '',
  `url` text NOT NULL,
  `sefurl` text NOT NULL,
  `newurl` text NOT NULL,
  PRIMARY KEY  (`itemid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_migration_backlinks`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_modules`
--

DROP TABLE IF EXISTS `jos_modules`;
CREATE TABLE IF NOT EXISTS `jos_modules` (
  `id` int(11) NOT NULL auto_increment,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `ordering` int(11) NOT NULL default '0',
  `position` varchar(50) default NULL,
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `module` varchar(50) default NULL,
  `numnews` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `showtitle` tinyint(3) unsigned NOT NULL default '1',
  `params` text NOT NULL,
  `iscore` tinyint(4) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  `control` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `published` (`published`,`access`),
  KEY `newsfeeds` (`module`,`published`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `jos_modules`
--

INSERT INTO `jos_modules` (`id`, `title`, `content`, `ordering`, `position`, `checked_out`, `checked_out_time`, `published`, `module`, `numnews`, `access`, `showtitle`, `params`, `iscore`, `client_id`, `control`) VALUES
(1, 'Main Menu', '', 1, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=mainmenu\nmoduleclass_sfx=_menu\n', 1, 0, ''),
(2, 'Login', '', 1, 'login', 0, '0000-00-00 00:00:00', 1, 'mod_login', 0, 0, 1, '', 1, 1, ''),
(3, 'Popular', '', 3, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_popular', 0, 2, 1, '', 0, 1, ''),
(4, 'Recent added Articles', '', 4, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_latest', 0, 2, 1, 'ordering=c_dsc\nuser_id=0\ncache=0\n\n', 0, 1, ''),
(5, 'Menu Stats', '', 5, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_stats', 0, 2, 1, '', 0, 1, ''),
(6, 'Unread Messages', '', 1, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_unread', 0, 2, 1, '', 1, 1, ''),
(7, 'Online Users', '', 2, 'header', 0, '0000-00-00 00:00:00', 1, 'mod_online', 0, 2, 1, '', 1, 1, ''),
(8, 'Toolbar', '', 1, 'toolbar', 0, '0000-00-00 00:00:00', 1, 'mod_toolbar', 0, 2, 1, '', 1, 1, ''),
(9, 'Quick Icons', '', 1, 'icon', 0, '0000-00-00 00:00:00', 1, 'mod_quickicon', 0, 2, 1, '', 1, 1, ''),
(10, 'Logged in Users', '', 2, 'cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_logged', 0, 2, 1, '', 0, 1, ''),
(11, 'Footer', '', 0, 'footer', 0, '0000-00-00 00:00:00', 1, 'mod_footer', 0, 0, 1, '', 1, 1, ''),
(12, 'Admin Menu', '', 1, 'menu', 0, '0000-00-00 00:00:00', 1, 'mod_menu', 0, 2, 1, '', 0, 1, ''),
(13, 'Admin SubMenu', '', 1, 'submenu', 0, '0000-00-00 00:00:00', 1, 'mod_submenu', 0, 2, 1, '', 0, 1, ''),
(14, 'User Status', '', 1, 'status', 0, '0000-00-00 00:00:00', 1, 'mod_status', 0, 2, 1, '', 0, 1, ''),
(15, 'Title', '', 1, 'title', 0, '0000-00-00 00:00:00', 1, 'mod_title', 0, 2, 1, '', 0, 1, ''),
(16, 'General Information', '', 2, 'left', 0, '0000-00-00 00:00:00', 1, 'mod_mainmenu', 0, 0, 1, 'menutype=generalinfo\nmenu_style=list\nstartLevel=0\nendLevel=0\nshowAllChildren=0\nwindow_open=\nshow_whitespace=0\ncache=1\ntag_id=\nclass_sfx=\nmoduleclass_sfx=\nmaxdepth=10\nmenu_images=0\nmenu_images_align=0\nmenu_images_link=0\nexpand_menu=0\nactivate_parent=0\nfull_active_id=0\nindent_image=0\nindent_image1=\nindent_image2=\nindent_image3=\nindent_image4=\nindent_image5=\nindent_image6=\nspacer=\\|\nend_spacer=\\|\n\n', 0, 0, ''),
(17, 'generalInfo', '', 3, 'left', 0, '0000-00-00 00:00:00', 0, 'mod_mainmenu', 0, 0, 1, 'menutype=generalinfo', 0, 0, ''),
(18, 'Search', '', 0, 'user4', 62, '2008-10-27 18:33:28', 1, 'mod_search', 0, 0, 0, 'moduleclass_sfx=\nwidth=20\ntext=Click here to search...\nbutton=1\nbutton_pos=right\nimagebutton=\nbutton_text=Search\ncache=1\ncache_time=900\n\n', 0, 0, ''),
(19, 'Breadcrumbs', '', 0, 'breadcrumbs', 0, '0000-00-00 00:00:00', 1, 'mod_breadcrumbs', 0, 0, 0, 'showHome=1\nhomeText=Home\nshowLast=1\nseparator=\nmoduleclass_sfx=\ncache=0\n\n', 0, 0, ''),
(20, 'JCE Latest News', '', 1, 'jce_cpanel', 0, '0000-00-00 00:00:00', 1, 'mod_feed', 0, 0, 1, 'cache=1\r\n	cache_time=15\r\n	moduleclass_sfx=\r\n	rssurl=http://www.joomlacontenteditor.net/index.php?option=com_rss&feed=RSS2.0&type=com_frontpage&Itemid=1\r\n	rssrtl=0\r\n	rsstitle=0\r\n	rssdesc=0\r\n	rssimage=0\r\n	rssitems=3\r\n	rssitemdesc=1\r\n	word_count=100', 0, 1, ''),
(21, 'JCE Control Panel Icons', '', 1, 'jce_icon', 0, '0000-00-00 00:00:00', 1, 'mod_jcequickicon', 0, 0, 0, '', 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_modules_menu`
--

DROP TABLE IF EXISTS `jos_modules_menu`;
CREATE TABLE IF NOT EXISTS `jos_modules_menu` (
  `moduleid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`moduleid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_modules_menu`
--

INSERT INTO `jos_modules_menu` (`moduleid`, `menuid`) VALUES
(1, 0),
(16, 0),
(17, 0),
(18, 0),
(19, 0);

-- --------------------------------------------------------

--
-- Table structure for table `jos_morfeoshow`
--

DROP TABLE IF EXISTS `jos_morfeoshow`;
CREATE TABLE IF NOT EXISTS `jos_morfeoshow` (
  `id` int(5) NOT NULL auto_increment,
  `name` varchar(128) NOT NULL default '',
  `description` text NOT NULL,
  `description1` text NOT NULL,
  `folder` varchar(32) NOT NULL default '',
  `shortcut_filename` varchar(128) NOT NULL default '',
  `published` tinyint(1) NOT NULL default '0',
  `flashgallery` int(2) NOT NULL default '0',
  `height` int(4) NOT NULL default '0',
  `width` int(4) NOT NULL default '0',
  `heightsw` int(4) NOT NULL default '0',
  `widthsw` int(4) NOT NULL default '0',
  `heightpc` int(4) NOT NULL default '0',
  `widthpc` int(4) NOT NULL default '0',
  `heightpl` int(4) NOT NULL default '0',
  `widthpl` int(4) NOT NULL default '0',
  `trans` int(2) NOT NULL default '0',
  `movimento` tinyint(1) NOT NULL default '1',
  `navigation` tinyint(1) NOT NULL default '1',
  `tempo` int(4) NOT NULL default '0',
  `bkgnd` varchar(12) NOT NULL default '',
  `bkgnd1` varchar(12) NOT NULL default '',
  `bkgnd2` varchar(12) NOT NULL default '',
  `bkgnd3` varchar(12) NOT NULL default '',
  `ordering` int(4) NOT NULL default '0',
  `metakey` text NOT NULL,
  `metadesc` text NOT NULL,
  `metadata` text NOT NULL,
  `glat` varchar(20) NOT NULL default '',
  `glng` varchar(20) NOT NULL default '',
  `gzoom` int(4) NOT NULL default '0',
  `gmapkey` varchar(100) NOT NULL default '',
  `luogo` varchar(128) NOT NULL default '',
  `user_id` varchar(255) NOT NULL default '',
  `group_id` varchar(255) NOT NULL default '',
  `text` varchar(255) NOT NULL default '',
  `tags` varchar(255) NOT NULL default '',
  `set_id` varchar(255) NOT NULL default '',
  `sort` int(4) NOT NULL default '0',
  `pusername` varchar(180) NOT NULL default '',
  `pphotosize` int(4) NOT NULL default '512',
  `pthumbsize` int(4) NOT NULL default '64',
  `palbumcols` int(4) NOT NULL default '3',
  `pcols` int(4) NOT NULL default '6',
  `pmaxresults` int(4) NOT NULL default '24',
  `pmaxalbums` int(4) NOT NULL default '4',
  `psingle` varchar(120) NOT NULL default '',
  `pback` varchar(10) NOT NULL default '',
  `paltezza` int(4) NOT NULL default '0',
  `plarghezza` int(4) NOT NULL default '0',
  `overstretch` tinyint(1) NOT NULL default '0',
  `shuffle` tinyint(1) NOT NULL default '0',
  `tclassic` int(4) NOT NULL default '0',
  `tcol` int(4) NOT NULL default '0',
  `orderfront` varchar(30) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_morfeoshow`
--

INSERT INTO `jos_morfeoshow` (`id`, `name`, `description`, `description1`, `folder`, `shortcut_filename`, `published`, `flashgallery`, `height`, `width`, `heightsw`, `widthsw`, `heightpc`, `widthpc`, `heightpl`, `widthpl`, `trans`, `movimento`, `navigation`, `tempo`, `bkgnd`, `bkgnd1`, `bkgnd2`, `bkgnd3`, `ordering`, `metakey`, `metadesc`, `metadata`, `glat`, `glng`, `gzoom`, `gmapkey`, `luogo`, `user_id`, `group_id`, `text`, `tags`, `set_id`, `sort`, `pusername`, `pphotosize`, `pthumbsize`, `palbumcols`, `pcols`, `pmaxresults`, `pmaxalbums`, `psingle`, `pback`, `paltezza`, `plarghezza`, `overstretch`, `shuffle`, `tclassic`, `tcol`, `orderfront`) VALUES
(2, 'Photo Gallery', 'The Southern Asia Division office.', 'A brief tour of the Southern Asia Division of Seventh-day Adventists office, located in Hosur, India.', 'southern_asi-9151', '', 1, 0, 400, 600, 680, 650, 480, 640, 680, 580, 0, 0, 1, 4, 'FFFFFF', '', '', '', 1, '', '', '', '', '', 0, '', '', '', '', '', 'sea', '72157602230948200', 0, '', 512, 64, 3, 6, 24, 4, '', 'FFFFFF', 420, 500, 0, 0, 0, 4, 'rand()');

-- --------------------------------------------------------

--
-- Table structure for table `jos_morfeoshow_img`
--

DROP TABLE IF EXISTS `jos_morfeoshow_img`;
CREATE TABLE IF NOT EXISTS `jos_morfeoshow_img` (
  `id` int(5) NOT NULL auto_increment,
  `gallery_id` int(5) NOT NULL default '0',
  `filename` varchar(128) NOT NULL default '',
  `title` text NOT NULL,
  `imgdate` datetime NOT NULL default '0000-00-00 00:00:00',
  `html` text NOT NULL,
  `height` int(4) NOT NULL default '0',
  `width` int(4) NOT NULL default '0',
  `creator` text NOT NULL,
  `link` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `jos_morfeoshow_img`
--

INSERT INTO `jos_morfeoshow_img` (`id`, `gallery_id`, `filename`, `title`, `imgdate`, `html`, `height`, `width`, `creator`, `link`) VALUES
(32, 2, 'DSCF9211.JPG', 'The Road', '2008-10-07 00:00:00', 'A road that runs past some of the Division employees'' offices.', 300, 400, '', ''),
(2, 1, 'DSC00351.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(3, 1, 'DSC00352.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(4, 1, 'DSC00519.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(5, 1, 'DSC00520.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(6, 1, 'DSC00521.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(7, 1, 'DSC00522.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(8, 1, 'DSC00523.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(9, 1, 'DSC00524.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(10, 1, 'DSC00525.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(11, 1, 'DSC00526.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(12, 1, 'DSC00527.JPG', '', '2008-10-07 00:00:00', '', 100, 78, '', ''),
(13, 1, 'DSC00528.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(14, 1, 'DSC00529.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(15, 1, 'DSC00530.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(16, 1, 'DSC00531.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(17, 1, 'DSC00532.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(18, 1, 'DSC00533.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(19, 1, 'DSC00534.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(20, 1, 'DSC00535.JPG', '', '2008-10-07 00:00:00', '', 60, 100, '', ''),
(21, 1, 'DSC00536.JPG', '', '2008-10-07 00:00:00', '', 65, 100, '', ''),
(22, 1, 'DSC00537.JPG', '', '2008-10-07 00:00:00', '', 88, 100, '', ''),
(23, 1, 'DSC00540.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(24, 1, 'DSC00541.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(25, 1, 'DSC00542.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(26, 1, 'DSC00544.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(27, 1, 'DSC00546.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(28, 1, 'DSC00548.JPG', '', '2008-10-07 00:00:00', '', 66, 100, '', ''),
(29, 1, 'Division_Office.JPG', '', '2008-10-07 00:00:00', '', 75, 100, '', ''),
(30, 1, 'IMG_0036.JPG', '', '2008-10-07 00:00:00', '', 75, 100, '', ''),
(31, 1, 'SS_Bldg_inauguration_014.jpg', '', '2008-10-07 00:00:00', '', 75, 100, '', ''),
(33, 2, 'DSCF9212.JPG', 'The Volleyball Court', '2008-10-07 00:00:00', 'The court where the Division employees'' kids can be found playing anything from volleyball to football.', 300, 400, '', ''),
(34, 2, 'DSCF9213.JPG', 'The Tennis Court', '2008-10-07 00:00:00', 'The tennis court on the campus, which, more often than tennis, is used for football.', 300, 400, '', ''),
(35, 2, 'DSCF9221.JPG', 'VHS Memorial', '2008-10-07 00:00:00', 'The Vincent Hill School Memorial building which houses the church library and Sabbath school rooms.', 300, 400, '', ''),
(36, 2, 'DSCF9222.JPG', 'Jeevan Joythi English Church', '2008-10-07 00:00:00', 'The church which the English-speaking employees at the division office regularly attend.', 300, 400, '', ''),
(37, 2, 'DSCF9223.JPG', 'The Division Office', '2008-10-07 00:00:00', 'The building where one will usually find the residents of the campus.', 300, 400, '', ''),
(42, 2, 'DSCF9237.JPG', 'The Sidewalk', '2008-10-07 00:00:00', '', 300, 400, '', ''),
(43, 2, 'DSCF9242.JPG', 'Inside the Office', '2008-10-07 00:00:00', 'The office building features a very nice open-air design which accommodates some beautiful plant growth.', 300, 400, '', ''),
(41, 2, 'DSCF9229.JPG', 'Outside the Guest Rooms', '2008-10-07 00:00:00', 'If one comes to visit, chances are he''ll be put up in one of the relaxing guest rooms.', 300, 400, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_morfeoshow_rating`
--

DROP TABLE IF EXISTS `jos_morfeoshow_rating`;
CREATE TABLE IF NOT EXISTS `jos_morfeoshow_rating` (
  `content_id` int(11) NOT NULL default '0',
  `rating_sum` int(11) unsigned NOT NULL default '0',
  `rating_count` int(11) unsigned NOT NULL default '0',
  `lastip` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`content_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_morfeoshow_rating`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_newsfeeds`
--

DROP TABLE IF EXISTS `jos_newsfeeds`;
CREATE TABLE IF NOT EXISTS `jos_newsfeeds` (
  `catid` int(11) NOT NULL default '0',
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `link` text NOT NULL,
  `filename` varchar(200) default NULL,
  `published` tinyint(1) NOT NULL default '0',
  `numarticles` int(11) unsigned NOT NULL default '1',
  `cache_time` int(11) unsigned NOT NULL default '3600',
  `checked_out` tinyint(3) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `rtl` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `published` (`published`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_newsfeeds`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_plugins`
--

DROP TABLE IF EXISTS `jos_plugins`;
CREATE TABLE IF NOT EXISTS `jos_plugins` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(100) NOT NULL default '',
  `element` varchar(100) NOT NULL default '',
  `folder` varchar(100) NOT NULL default '',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `ordering` int(11) NOT NULL default '0',
  `published` tinyint(3) NOT NULL default '0',
  `iscore` tinyint(3) NOT NULL default '0',
  `client_id` tinyint(3) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_folder` (`published`,`client_id`,`access`,`folder`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `jos_plugins`
--

INSERT INTO `jos_plugins` (`id`, `name`, `element`, `folder`, `access`, `ordering`, `published`, `iscore`, `client_id`, `checked_out`, `checked_out_time`, `params`) VALUES
(1, 'Authentication - Joomla', 'joomla', 'authentication', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(2, 'Authentication - LDAP', 'ldap', 'authentication', 0, 2, 0, 1, 0, 0, '0000-00-00 00:00:00', 'host=\nport=389\nuse_ldapV3=0\nnegotiate_tls=0\nno_referrals=0\nauth_method=bind\nbase_dn=\nsearch_string=\nusers_dn=\nusername=\npassword=\nldap_fullname=fullName\nldap_email=mail\nldap_uid=uid\n\n'),
(3, 'Authentication - GMail', 'gmail', 'authentication', 0, 4, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(4, 'Authentication - OpenID', 'openid', 'authentication', 0, 3, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(5, 'User - Joomla!', 'joomla', 'user', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'autoregister=1\n\n'),
(6, 'Search - Content', 'content', 'search', 0, 1, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\nsearch_content=1\nsearch_uncategorised=1\nsearch_archived=1\n\n'),
(7, 'Search - Contacts', 'contacts', 'search', 0, 3, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(8, 'Search - Categories', 'categories', 'search', 0, 4, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(9, 'Search - Sections', 'sections', 'search', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(10, 'Search - Newsfeeds', 'newsfeeds', 'search', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(11, 'Search - Weblinks', 'weblinks', 'search', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'search_limit=50\n\n'),
(12, 'Content - Pagebreak', 'pagebreak', 'content', 0, 10000, 1, 1, 0, 0, '0000-00-00 00:00:00', 'enabled=1\ntitle=1\nmultipage_toc=1\nshowall=1\n\n'),
(13, 'Content - Rating', 'vote', 'content', 0, 4, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(14, 'Content - Email Cloaking', 'emailcloak', 'content', 0, 5, 1, 0, 0, 0, '0000-00-00 00:00:00', 'mode=1\n\n'),
(15, 'Content - Code Hightlighter (GeSHi)', 'geshi', 'content', 0, 5, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(16, 'Content - Load Module', 'loadmodule', 'content', 0, 6, 1, 0, 0, 0, '0000-00-00 00:00:00', 'enabled=1\nstyle=0\n\n'),
(17, 'Content - Page Navigation', 'pagenavigation', 'content', 0, 2, 1, 1, 0, 0, '0000-00-00 00:00:00', 'position=1\n\n'),
(18, 'Editor - No Editor', 'none', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(19, 'Editor - TinyMCE 2.0', 'tinymce', 'editors', 0, 0, 1, 1, 0, 0, '0000-00-00 00:00:00', 'theme=advanced\ncleanup=1\ncleanup_startup=0\nautosave=0\ncompressed=0\nrelative_urls=1\ntext_direction=ltr\nlang_mode=0\nlang_code=en\ninvalid_elements=applet\ncontent_css=1\ncontent_css_custom=\nnewlines=0\ntoolbar=top\nhr=1\nsmilies=1\ntable=1\nstyle=1\nlayer=1\nxhtmlxtras=0\ntemplate=0\ndirectionality=1\nfullscreen=1\nhtml_height=550\nhtml_width=750\npreview=1\ninsertdate=1\nformat_date=%Y-%m-%d\ninserttime=1\nformat_time=%H:%M:%S\n\n'),
(20, 'Editor - XStandard Lite 2.0', 'xstandard', 'editors', 0, 0, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(21, 'Editor Button - Image', 'image', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(22, 'Editor Button - Pagebreak', 'pagebreak', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(23, 'Editor Button - Readmore', 'readmore', 'editors-xtd', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(24, 'XML-RPC - Joomla', 'joomla', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(25, 'XML-RPC - Blogger API', 'blogger', 'xmlrpc', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', 'catid=1\nsectionid=0\n\n'),
(27, 'System - SEF', 'sef', 'system', 0, 1, 1, 0, 0, 0, '0000-00-00 00:00:00', ''),
(28, 'System - Debug', 'debug', 'system', 0, 2, 1, 0, 0, 0, '0000-00-00 00:00:00', 'queries=1\nmemory=1\nlangauge=1\n\n'),
(29, 'System - Legacy', 'legacy', 'system', 0, 3, 0, 1, 0, 0, '0000-00-00 00:00:00', 'route=0\n\n'),
(30, 'System - Cache', 'cache', 'system', 0, 4, 0, 1, 0, 0, '0000-00-00 00:00:00', 'browsercache=0\ncachetime=15\n\n'),
(31, 'System - Log', 'log', 'system', 0, 5, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(32, 'System - Remember Me', 'remember', 'system', 0, 6, 1, 1, 0, 0, '0000-00-00 00:00:00', ''),
(33, 'System - Backlink', 'backlink', 'system', 0, 7, 0, 1, 0, 0, '0000-00-00 00:00:00', ''),
(34, 'Content - MorfeoShow', 'morfeoshow', 'content', 0, 0, 0, 0, 0, 0, '0000-00-00 00:00:00', ''),
(35, 'Editor - JCE 1.5.1', 'jce', 'editors', 0, 0, 1, 0, 0, 0, '0000-00-00 00:00:00', 'editor_state=mceEditor\neditor_toggle_text=[show/hide]\neditor_layout_rows=5\n');

-- --------------------------------------------------------

--
-- Table structure for table `jos_polls`
--

DROP TABLE IF EXISTS `jos_polls`;
CREATE TABLE IF NOT EXISTS `jos_polls` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `voters` int(9) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `published` tinyint(1) NOT NULL default '0',
  `access` int(11) NOT NULL default '0',
  `lag` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_polls`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_data`
--

DROP TABLE IF EXISTS `jos_poll_data`;
CREATE TABLE IF NOT EXISTS `jos_poll_data` (
  `id` int(11) NOT NULL auto_increment,
  `pollid` int(11) NOT NULL default '0',
  `text` text NOT NULL,
  `hits` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `pollid` (`pollid`,`text`(1))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_date`
--

DROP TABLE IF EXISTS `jos_poll_date`;
CREATE TABLE IF NOT EXISTS `jos_poll_date` (
  `id` bigint(20) NOT NULL auto_increment,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `vote_id` int(11) NOT NULL default '0',
  `poll_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`id`),
  KEY `poll_id` (`poll_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_poll_date`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_poll_menu`
--

DROP TABLE IF EXISTS `jos_poll_menu`;
CREATE TABLE IF NOT EXISTS `jos_poll_menu` (
  `pollid` int(11) NOT NULL default '0',
  `menuid` int(11) NOT NULL default '0',
  PRIMARY KEY  (`pollid`,`menuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_poll_menu`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_qcontacts_details`
--

DROP TABLE IF EXISTS `jos_qcontacts_details`;
CREATE TABLE IF NOT EXISTS `jos_qcontacts_details` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `alias` varchar(255) NOT NULL default '',
  `con_position` text,
  `address` text,
  `suburb` text,
  `state` text,
  `country` text,
  `postcode` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `fax` varchar(255) default NULL,
  `misc` mediumtext,
  `image` varchar(255) default NULL,
  `imagepos` varchar(60) default NULL,
  `email_to` varchar(255) default NULL,
  `default_con` tinyint(1) unsigned NOT NULL default '0',
  `published` tinyint(1) unsigned NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  `user_id` int(11) NOT NULL default '0',
  `catid` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `mobile` varchar(255) NOT NULL default '',
  `webpage` varchar(255) NOT NULL default '',
  `skype` varchar(255) NOT NULL default '',
  `yahoo_msg` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `jos_qcontacts_details`
--

INSERT INTO `jos_qcontacts_details` (`id`, `name`, `alias`, `con_position`, `address`, `suburb`, `state`, `country`, `postcode`, `telephone`, `fax`, `misc`, `image`, `imagepos`, `email_to`, `default_con`, `published`, `checked_out`, `checked_out_time`, `ordering`, `params`, `user_id`, `catid`, `access`, `mobile`, `webpage`, `skype`, `yahoo_msg`) VALUES
(1, 'Dr.  Gollakoti Nageshwar Rao, Ph.D', 'dr-gollakoti-nageshwar-rao-phd', 'Director', '', '', '', '', '', '', '', '', 'DSC00604p.jpg', '', 'rao@sud-adventist.org', 0, 1, 0, '0000-00-00 00:00:00', 1, 'show_name=1\nshow_position=1\nshow_image=1\ncimage_align=\nshow_email=0\nshow_street_address=1\nshow_suburb=1\nshow_state=1\nshow_postcode=1\nshow_country=1\nshow_telephone=1\nshow_mobile=1\nshow_fax=1\nshow_skype=\nshow_yahoo=\nshow_webpage=1\nshow_misc=1\nallow_vcard=0\ncontact_icons=0\nicon_address=\nicon_email=\nicon_telephone=\nicon_mobile=\nicon_fax=\nicon_skype=\nicon_yahoo=\nicon_web=\nicon_misc=\nshow_email_form=0\nshow_email_copy=0\nbanned_email=\nbanned_subject=\nbanned_text=\nshow_captcha=\ncaptcha_length=\ncaptcha_width=\ncaptcha_height=\ncaptcha_font=\ncaptcha_fsize=\ncaptcha_bgcolor=\ncaptcha_txtcolor=\ncaptcha_lines=\ncaptcha_lines_color=\ncaptcha_lines_distance=5\ncaptcha_arclines=\ncaptcha_arclines_color=\nname_size=\nname_ord=\nemail_size=\nemail_ord=\nsubject_show=\nsubject_size=\nsubject_ord=\nmessage_size=\nmessage_ord=\ncust1_show=\ncust1_label=\ncust1_type=\ncust1_size=\ncust1_value=\ncust1_ord=\ncust2_show=\ncust2_label=\ncust2_type=\ncust2_size=\ncust2_value=\ncust2_ord=\ncust3_show=\ncust3_label=\ncust3_type=\ncust3_size=\ncust3_value=\ncust3_ord=\ncust4_show=\ncust4_label=\ncust4_type=\ncust4_size=\ncust4_value=\ncust4_ord=\ncust5_show=\ncust5_label=\ncust5_type=\ncust5_size=\ncust5_value=\ncust5_ord=\ncust6_show=\ncust6_label=\ncust6_type=\ncust6_size=\ncust6_value=\ncust6_ord=', 0, 4, 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_sections`
--

DROP TABLE IF EXISTS `jos_sections`;
CREATE TABLE IF NOT EXISTS `jos_sections` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `name` varchar(255) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `image` text NOT NULL,
  `scope` varchar(50) NOT NULL default '',
  `image_position` varchar(30) NOT NULL default '',
  `description` text NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) unsigned NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `access` tinyint(3) unsigned NOT NULL default '0',
  `count` int(11) NOT NULL default '0',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `idx_scope` (`scope`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `jos_sections`
--

INSERT INTO `jos_sections` (`id`, `title`, `name`, `alias`, `image`, `scope`, `image_position`, `description`, `published`, `checked_out`, `checked_out_time`, `ordering`, `access`, `count`, `params`) VALUES
(1, 'General Information', '', 'general-information', '', 'content', 'left', 'Information about the Southern Asia Division and Seventh-day Adventists in general.', 1, 0, '0000-00-00 00:00:00', 1, 0, 2, ''),
(2, 'Lists', '', 'lists', '', 'content', 'left', '', 1, 0, '0000-00-00 00:00:00', 2, 0, 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `jos_session`
--

DROP TABLE IF EXISTS `jos_session`;
CREATE TABLE IF NOT EXISTS `jos_session` (
  `username` varchar(150) default '',
  `time` varchar(14) default '',
  `session_id` varchar(200) NOT NULL default '0',
  `guest` tinyint(4) default '1',
  `userid` int(11) default '0',
  `usertype` varchar(50) default '',
  `gid` tinyint(3) unsigned NOT NULL default '0',
  `client_id` tinyint(3) unsigned NOT NULL default '0',
  `data` longtext,
  PRIMARY KEY  (`session_id`(64)),
  KEY `whosonline` (`guest`,`usertype`),
  KEY `userid` (`userid`),
  KEY `time` (`time`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_session`
--

INSERT INTO `jos_session` (`username`, `time`, `session_id`, `guest`, `userid`, `usertype`, `gid`, `client_id`, `data`) VALUES
('', '1225688366', '3fdaa8c6be3de22252c14b19680ca653', 1, 0, '', 0, 0, '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1225688366;s:18:"session.timer.last";i:1225688366;s:17:"session.timer.now";i:1225688366;s:22:"session.client.browser";s:90:"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:66:"/home/adventis/public_html/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}}'),
('', '1225687966', 'db6f01a43a5761ff17fcdeb4ff4512c0', 1, 0, '', 0, 1, '__default|a:5:{s:22:"session.client.browser";s:90:"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3";s:15:"session.counter";i:1;s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:66:"/home/adventis/public_html/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}s:13:"session.token";s:32:"689246aba5c70553c39f71073232cd46";}'),
('', '1225687966', '5ce0a5061eb3281f2fedf962dc64389f', 1, 0, '', 0, 0, '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1225687966;s:18:"session.timer.last";i:1225687966;s:17:"session.timer.now";i:1225687966;s:22:"session.client.browser";s:90:"Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:66:"/home/adventis/public_html/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}}'),
('', '1225688094', 'f15d41273fd52edf8c6e5948d4236b59', 1, 0, '', 0, 0, '__default|a:7:{s:15:"session.counter";i:1;s:19:"session.timer.start";i:1225688094;s:18:"session.timer.last";i:1225688094;s:17:"session.timer.now";i:1225688094;s:22:"session.client.browser";s:87:"Mozilla/5.0 (compatible; Yahoo! Slurp/3.0; http://help.yahoo.com/help/us/ysearch/slurp)";s:8:"registry";O:9:"JRegistry":3:{s:17:"_defaultNameSpace";s:7:"session";s:9:"_registry";a:1:{s:7:"session";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:4:"user";O:5:"JUser":19:{s:2:"id";i:0;s:4:"name";N;s:8:"username";N;s:5:"email";N;s:8:"password";N;s:14:"password_clear";s:0:"";s:8:"usertype";N;s:5:"block";N;s:9:"sendEmail";i:0;s:3:"gid";i:0;s:12:"registerDate";N;s:13:"lastvisitDate";N;s:10:"activation";N;s:6:"params";N;s:3:"aid";i:0;s:5:"guest";i:1;s:7:"_params";O:10:"JParameter":7:{s:4:"_raw";s:0:"";s:4:"_xml";N;s:9:"_elements";a:0:{}s:12:"_elementPath";a:1:{i:0;s:66:"/home/adventis/public_html/libraries/joomla/html/parameter/element";}s:17:"_defaultNameSpace";s:8:"_default";s:9:"_registry";a:1:{s:8:"_default";a:1:{s:4:"data";O:8:"stdClass":0:{}}}s:7:"_errors";a:0:{}}s:9:"_errorMsg";N;s:7:"_errors";a:0:{}}}');

-- --------------------------------------------------------

--
-- Table structure for table `jos_stats_agents`
--

DROP TABLE IF EXISTS `jos_stats_agents`;
CREATE TABLE IF NOT EXISTS `jos_stats_agents` (
  `agent` varchar(255) NOT NULL default '',
  `type` tinyint(1) unsigned NOT NULL default '0',
  `hits` int(11) unsigned NOT NULL default '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_stats_agents`
--


-- --------------------------------------------------------

--
-- Table structure for table `jos_templates_menu`
--

DROP TABLE IF EXISTS `jos_templates_menu`;
CREATE TABLE IF NOT EXISTS `jos_templates_menu` (
  `template` varchar(255) NOT NULL default '',
  `menuid` int(11) NOT NULL default '0',
  `client_id` tinyint(4) NOT NULL default '0',
  PRIMARY KEY  (`menuid`,`client_id`,`template`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `jos_templates_menu`
--

INSERT INTO `jos_templates_menu` (`template`, `menuid`, `client_id`) VALUES
('ja_purity', 0, 0),
('khepri', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `jos_weblinks`
--

DROP TABLE IF EXISTS `jos_weblinks`;
CREATE TABLE IF NOT EXISTS `jos_weblinks` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `catid` int(11) NOT NULL default '0',
  `sid` int(11) NOT NULL default '0',
  `title` varchar(250) NOT NULL default '',
  `alias` varchar(255) NOT NULL default '',
  `url` varchar(250) NOT NULL default '',
  `description` text NOT NULL,
  `date` datetime NOT NULL default '0000-00-00 00:00:00',
  `hits` int(11) NOT NULL default '0',
  `published` tinyint(1) NOT NULL default '0',
  `checked_out` int(11) NOT NULL default '0',
  `checked_out_time` datetime NOT NULL default '0000-00-00 00:00:00',
  `ordering` int(11) NOT NULL default '0',
  `archived` tinyint(1) NOT NULL default '0',
  `approved` tinyint(1) NOT NULL default '1',
  `params` text NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `catid` (`catid`,`published`,`archived`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `jos_weblinks`
--

